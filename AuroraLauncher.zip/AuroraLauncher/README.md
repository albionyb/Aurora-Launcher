# Aurora Launcher

A real Android home launcher (Kotlin, Jetpack Compose, Material 3, Room, DataStore, Coroutines/Flow).
No internet permission, no analytics, no accounts. Min SDK 26, target SDK 35.

## Build

**Android Studio:** unzip, File > Open, let Gradle sync, press Run. APK: `app/build/outputs/apk/debug/`.

**GitHub Actions (no PC needed):**
1. Create an empty GitHub repository.
2. Upload `AuroraLauncher.zip` to the repo root.
3. Create the file `.github/workflows/build.yml` (use "Add file > Create new file", type the path with slashes) and paste the contents of `build-from-zip.yml`.
4. Open the **Actions** tab, wait for "Build APK from zip", open the run and download **AuroraLauncher-debug-apk**. Unzip it and install the `.apk` (allow "install unknown apps").
5. Open Aurora, accept "Choose" in the prompt (or Settings > Apps > Default apps > Home app) to make it your launcher.

If the build fails, open the failed step, copy the red error lines and send them over; they are quick to fix.

## Implemented
- Real HOME launcher (intent filter, singleTask, RoleManager default-launcher flow, Home button handling).
- Installed apps via LauncherApps (work profiles, live updates on install/uninstall), adaptive icons.
- Home: paged grid, dock, folders, drag-and-drop (incl. from drawer, edge-hover page flip, drop-to-remove), long-press menus with real app shortcuts, app info, uninstall, clock/date, search pill, page indicator, scroll effects.
- Drawer: A-Z index, categories, frequent/recent suggestions, sorting, hidden apps, swipe-down close, drag to home.
- Search: ranked real-time filter, recent searches, suggestions, device settings shortcuts, keyboard-first.
- Customization: theme (light/dark/system), dynamic color, accent, dimming, glass opacity, wallpaper blur (Android 12+), icon size/shape/theme (original, grayscale, tinted), labels, grid, dock, spacing, folder style, gestures (swipe up/down, double tap, pinch), launch animation and speed. All persisted in DataStore.
- Backup/restore of settings and layout to a JSON file.

## Not implemented yet / limitations
- Widgets (AppWidgetHost), third-party icon packs, notification badges: planned next phases.
- Double-tap-to-lock needs an accessibility service, so it is not offered.
- Notification shade gesture uses a non-public framework call; it may not work on every device.
- Wallpaper blur needs Android 12+ and "cross-window blur" enabled by the system.
- App shortcuts in the long-press menu only appear once Aurora is the default launcher.
- This code was written without a compiler available; expect to fix a few compile errors on the first build.

## Permissions
QUERY_ALL_PACKAGES (list every app), REQUEST_DELETE_PACKAGES (uninstall dialog), EXPAND_STATUS_BAR (swipe-down gesture).
