package com.aurora.launcher.ui.home

import android.view.View
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.launcher.data.AppInfo
import com.aurora.launcher.data.FolderStyle
import com.aurora.launcher.data.HomeItem
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.ui.LauncherViewModel
import com.aurora.launcher.ui.components.AppIconView
import com.aurora.launcher.ui.components.DragPayload
import com.aurora.launcher.ui.components.DragState
import com.aurora.launcher.ui.components.IconArt
import com.aurora.launcher.ui.components.MenuAction
import com.aurora.launcher.ui.components.appRepository
import com.aurora.launcher.ui.components.dragSource
import com.aurora.launcher.ui.components.glass
import com.aurora.launcher.ui.theme.LocalAurora
import androidx.compose.ui.platform.LocalContext

/** Folder as shown on the home screen / dock: a glass tile with a 2x2 preview of its apps. */
@Composable
fun FolderIconView(
    folder: HomeItem,
    members: List<AppInfo>,
    settings: LauncherSettings,
    drag: DragState,
    showLabel: Boolean,
    dimmed: Boolean,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = settings.iconSizeDp.dp,
) {
    var menuOpen by remember { mutableStateOf(false) }
    val shape = if (settings.folderStyle == FolderStyle.CIRCLE) CircleShape else RoundedCornerShape(30)
    Column(
        modifier = modifier
            .alpha(if (dimmed) 0.25f else 1f)
            .dragSource(
                onTap = { onOpen() },
                onMenu = { menuOpen = true },
                onDragStart = { drag.start(DragPayload.FromHome(folder, null), it) },
                onDrag = drag::move,
                onDragEnd = drag::end,
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(iconSize).glass(shape, strong = true).padding(iconSize * 0.12f)) {
            val mini = iconSize * 0.34f
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                for (row in 0..1) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        for (col in 0..1) {
                            val app = members.getOrNull(row * 2 + col)
                            if (app != null) IconArt(app, settings, mini) else Box(Modifier.size(mini))
                        }
                    }
                }
            }
            DropdownMenu(
                expanded = menuOpen,
                onDismissRequest = { menuOpen = false },
                shape = RoundedCornerShape(20.dp),
                containerColor = MaterialTheme.colorScheme.surface,
            ) {
                DropdownMenuItem(
                    text = { Text("Rename") },
                    leadingIcon = { Icon(Icons.Outlined.Edit, null, Modifier.size(20.dp)) },
                    onClick = { menuOpen = false; onRename() },
                )
                DropdownMenuItem(
                    text = { Text("Remove folder") },
                    leadingIcon = { Icon(Icons.Outlined.Delete, null, Modifier.size(20.dp)) },
                    onClick = { menuOpen = false; onRemove() },
                )
            }
        }
        if (showLabel) {
            Text(
                folder.title ?: "Folder",
                color = LocalAurora.current.onWallpaper,
                fontSize = settings.labelSizeSp.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(top = 4.dp).widthIn(max = iconSize + 20.dp),
            )
        }
    }
}

/**
 * Opened folder. Apps can be launched, dragged out onto the home screen, or sent back
 * with the menu. The panel hides itself (but stays composed) while a drag is in flight.
 */
@Composable
fun FolderPopup(
    folder: HomeItem,
    memberItems: List<HomeItem>,
    appsByKey: Map<String, AppInfo>,
    settings: LauncherSettings,
    vm: LauncherViewModel,
    drag: DragState,
    startRename: Boolean,
    onClose: () -> Unit,
) {
    val view: View = LocalView.current
    val repo = LocalContext.current.appRepository()
    val focus = LocalFocusManager.current
    val requester = remember { FocusRequester() }
    var title by remember(folder.id) { mutableStateOf(folder.title ?: "Folder") }
    var wasDragging by remember { mutableStateOf(false) }

    fun commit() { if (title != folder.title) vm.renameFolder(folder, title) }

    LaunchedEffect(drag.active) {
        if (drag.active) wasDragging = true else if (wasDragging) onClose()
    }
    LaunchedEffect(startRename) { if (startRename) requester.requestFocus() }

    Box(
        Modifier
            .fillMaxSize()
            .alpha(if (drag.active) 0f else 1f)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                commit(); onClose()
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .padding(24.dp)
                .glass(RoundedCornerShape(32.dp), strong = true)
                // Swallow taps inside the panel so they don't close the folder.
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BasicTextField(
                value = title,
                onValueChange = { title = it.take(24) },
                singleLine = true,
                textStyle = MaterialTheme.typography.titleLarge.copy(
                    color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { commit(); focus.clearFocus() }),
                modifier = Modifier
                    .padding(bottom = 12.dp)
                    .focusRequester(requester)
                    .onFocusChanged { if (!it.isFocused) commit() },
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.heightIn(max = 380.dp).widthIn(max = 360.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(memberItems.sortedBy { it.cellX }, key = { it.id }) { item ->
                    val app = appsByKey[item.appKey] ?: return@items
                    AppIconView(
                        app = app,
                        settings = settings,
                        drag = drag,
                        payload = DragPayload.FromHome(item, app),
                        labelColor = MaterialTheme.colorScheme.onSurface,
                        actions = listOf(
                            MenuAction("Move to home", Icons.Outlined.Home) { vm.removeFromFolder(item) },
                            MenuAction("App info", Icons.Outlined.Info) { repo.openAppInfo(app) },
                            MenuAction("Uninstall", Icons.Outlined.Delete) { repo.uninstall(app) },
                        ),
                        onLaunch = { bounds ->
                            vm.launch(app, bounds.toAndroid(), launchOptions(settings, repo, view, bounds))
                        },
                    )
                }
            }
        }
    }
}
