package com.aurora.launcher.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * Backup format (version 1): one JSON document with every setting (type-tagged so it
 * restores exactly) and the full home layout. Nothing leaves the device unless the user
 * picks a destination in the system file picker.
 */
object Backup {
    private const val VERSION = 1

    class Parsed(val settings: Map<String, Any>, val items: List<HomeItem>)

    fun toJson(settings: Map<String, Any>, items: List<HomeItem>): String {
        val s = JSONArray()
        for ((name, value) in settings) {
            val (type, v) = when (value) {
                is Boolean -> "bool" to value
                is Int -> "int" to value
                is Float -> "float" to value.toDouble()
                is String -> "string" to value
                is Set<*> -> "set" to JSONArray(value.filterIsInstance<String>())
                else -> continue
            }
            s.put(JSONObject().put("name", name).put("type", type).put("value", v))
        }
        val i = JSONArray()
        for (it in items) {
            i.put(
                JSONObject()
                    .put("id", it.id).put("type", it.type).put("container", it.container)
                    .put("parentId", it.parentId).put("page", it.page)
                    .put("cellX", it.cellX).put("cellY", it.cellY)
                    .put("appKey", it.appKey ?: JSONObject.NULL)
                    .put("title", it.title ?: JSONObject.NULL)
            )
        }
        return JSONObject().put("app", "aurora-launcher").put("version", VERSION)
            .put("settings", s).put("items", i).toString(2)
    }

    /** Returns null when the file is not a valid Aurora backup. */
    fun parse(json: String): Parsed? = try {
        val root = JSONObject(json)
        require(root.optString("app") == "aurora-launcher")
        require(root.optInt("version") <= VERSION)
        val settings = LinkedHashMap<String, Any>()
        val sa = root.getJSONArray("settings")
        for (n in 0 until sa.length()) {
            val o = sa.getJSONObject(n)
            val name = o.getString("name")
            when (o.getString("type")) {
                "bool" -> settings[name] = o.getBoolean("value")
                "int" -> settings[name] = o.getInt("value")
                "float" -> settings[name] = o.getDouble("value").toFloat()
                "string" -> settings[name] = o.getString("value")
                "set" -> {
                    val arr = o.getJSONArray("value")
                    settings[name] = (0 until arr.length()).map { arr.getString(it) }.toSet()
                }
            }
        }
        val items = ArrayList<HomeItem>()
        val ia = root.getJSONArray("items")
        for (n in 0 until ia.length()) {
            val o = ia.getJSONObject(n)
            items += HomeItem(
                id = o.getLong("id"), type = o.getString("type"), container = o.getString("container"),
                parentId = o.optLong("parentId"), page = o.optInt("page"),
                cellX = o.optInt("cellX"), cellY = o.optInt("cellY"),
                appKey = if (o.isNull("appKey")) null else o.getString("appKey"),
                title = if (o.isNull("title")) null else o.getString("title"),
            )
        }
        Parsed(settings, items)
    } catch (e: Exception) {
        null
    }
}
