package com.aurora.launcher.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Fullscreen
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.launcher.data.AppInfo
import com.aurora.launcher.data.GestureAction
import com.aurora.launcher.data.Container
import com.aurora.launcher.data.Keys
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.ui.components.DragPayload
import com.aurora.launcher.ui.components.DragState
import com.aurora.launcher.ui.components.IconArt
import com.aurora.launcher.ui.components.glass
import com.aurora.launcher.ui.drawer.AppDrawer
import com.aurora.launcher.ui.home.FolderPopup
import com.aurora.launcher.ui.home.HomeScreen
import com.aurora.launcher.ui.search.SearchOverlay
import com.aurora.launcher.ui.search.openSystemSettings
import com.aurora.launcher.ui.settings.SettingsScreen
import com.aurora.launcher.ui.theme.AuroraTheme
import kotlin.math.max

@Composable
fun MainScreen(vm: LauncherViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    AuroraTheme(settings) { Launcher(vm, settings) }
}

@SuppressLint("WrongConstant")
private fun expandNotifications(context: Context) {
    // The framework offers no public API for this; the call is best-effort and silently ignored if blocked.
    try {
        val bar = context.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(bar)
    } catch (_: Throwable) {
    }
}

@Composable
private fun Launcher(vm: LauncherViewModel, settings: LauncherSettings) {
    val context = LocalContext.current
    val window = (context as Activity).window
    val drag = remember { DragState() }
    val items by vm.homeItems.collectAsStateWithLifecycle()
    val appsByKey by vm.appsByKey.collectAsStateWithLifecycle()
    val default = rememberDefaultLauncher()

    var drawerOpen by rememberSaveable { mutableStateOf(false) }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    var homeMenuOpen by rememberSaveable { mutableStateOf(false) }
    var folderId by rememberSaveable { mutableStateOf<Long?>(null) }
    var folderRename by rememberSaveable { mutableStateOf(false) }
    var defaultPromptShown by rememberSaveable { mutableStateOf(false) }

    val speed = settings.animationSpeed
    fun ms(base: Int) = (base / speed).toInt().coerceAtLeast(60)

    fun closeAll() {
        drawerOpen = false; searchOpen = false; settingsOpen = false; homeMenuOpen = false; folderId = null
    }

    fun perform(a: GestureAction) {
        when (a) {
            GestureAction.NONE -> Unit
            GestureAction.OPEN_DRAWER -> drawerOpen = true
            GestureAction.OPEN_SEARCH -> searchOpen = true
            GestureAction.OPEN_NOTIFICATIONS -> expandNotifications(context)
            GestureAction.OPEN_SETTINGS -> settingsOpen = true
        }
    }

    // Home button: collapse everything back to the home screen.
    LaunchedEffect(Unit) { vm.homePressed.collect { closeAll() } }
    // Starting a drag from the drawer hands the finger over to the home screen.
    LaunchedEffect(drag.payload) { if (drag.fromDrawer) drawerOpen = false }

    BackHandler(enabled = folderId != null || searchOpen || settingsOpen || drawerOpen || homeMenuOpen) {
        when {
            homeMenuOpen -> homeMenuOpen = false
            folderId != null -> folderId = null
            searchOpen -> searchOpen = false
            settingsOpen -> settingsOpen = false
            drawerOpen -> drawerOpen = false
        }
    }

    // ----- Drawer progress (also drives home dimming and wallpaper blur) -----
    val drawerProgress by animateFloatAsState(
        targetValue = if (drawerOpen && !drag.active) 1f else 0f,
        animationSpec = tween(ms(320), easing = FastOutSlowInEasing),
        label = "drawer",
    )
    val searchProgress by animateFloatAsState(
        targetValue = if (searchOpen) 1f else 0f,
        animationSpec = tween(ms(260)),
        label = "search",
    )
    val blurOn = settings.blurWallpaper
    LaunchedEffect(blurOn) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            snapshotFlow { max(drawerProgress, searchProgress) }.collect { p ->
                val wm = context.getSystemService(WindowManager::class.java)
                val r = if (blurOn && wm.isCrossWindowBlurEnabled) (p * 48f).toInt() else 0
                window.setBackgroundBlurRadius(r)
            }
        }
    }

    // ----- System bar icon color and visibility follow what is behind them -----
    val lightSurface = MaterialTheme.colorScheme.background.luminance() > 0.5f
    val overlaysCoverWallpaper = settingsOpen || searchOpen || drawerOpen
    val view = LocalView.current
    SideEffect {
        val c = WindowCompat.getInsetsController(window, view)
        val darkIcons = overlaysCoverWallpaper && lightSurface
        c.isAppearanceLightStatusBars = darkIcons
        c.isAppearanceLightNavigationBars = darkIcons

        if (settings.showStatusBar) {
            c.show(WindowInsetsCompat.Type.statusBars())
        } else {
            c.hide(WindowInsetsCompat.Type.statusBars())
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = settings.dimAmount))) {
        HomeScreen(
            vm = vm, settings = settings, drag = drag,
            onOpenSearch = { searchOpen = true },
            onOpenFolder = { id, rename -> folderId = id; folderRename = rename },
            onHomeMenu = { homeMenuOpen = true },
            onGesture = ::perform,
            modifier = Modifier.graphicsLayer {
                alpha = 1f - 0.5f * drawerProgress
                scaleX = 1f - 0.05f * drawerProgress
                scaleY = 1f - 0.05f * drawerProgress
            },
        )

        if (drawerProgress > 0.001f || drag.fromDrawer) {
            AppDrawer(
                vm = vm, settings = settings, drag = drag,
                onOpenSearch = { searchOpen = true },
                onClose = { drawerOpen = false },
                modifier = Modifier.graphicsLayer {
                    alpha = drawerProgress
                    translationY = (1f - drawerProgress) * size.height * 0.08f
                },
            )
        }

        val folder = folderId?.let { id -> items.firstOrNull { it.id == id } }
        if (folderId != null && folder == null) folderId = null // folder dissolved while open
        if (folder != null) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (drag.active) 0f else 0.4f)))
            FolderPopup(
                folder = folder,
                memberItems = items.filter { it.container == Container.FOLDER && it.parentId == folder.id },
                appsByKey = appsByKey,
                settings = settings, vm = vm, drag = drag,
                startRename = folderRename,
                onClose = { folderId = null },
            )
        }

        AnimatedVisibility(
            visible = searchOpen,
            enter = fadeIn(tween(ms(220))) + slideInVertically(tween(ms(260))) { it / 14 },
            exit = fadeOut(tween(ms(180))) + slideOutVertically(tween(ms(220))) { it / 14 },
        ) {
            SearchOverlay(vm, settings) { searchOpen = false }
        }

        AnimatedVisibility(
            visible = settingsOpen,
            enter = slideInHorizontally(tween(ms(280))) { it / 3 } + fadeIn(tween(ms(220))),
            exit = slideOutHorizontally(tween(ms(220))) { it / 3 } + fadeOut(tween(ms(180))),
        ) {
            SettingsScreen(vm, settings) { settingsOpen = false }
        }

        DragGhost(drag, settings)

        if (homeMenuOpen) {
            HomeMenu(
                settings = settings,
                onDismiss = { homeMenuOpen = false },
                onToggleSearch = { vm.set(Keys.SHOW_SEARCH, !settings.showSearchBar) },
                onToggleClock = { vm.set(Keys.SHOW_CLOCK, !settings.showClock) },
                onToggleStatusBar = { vm.set(Keys.SHOW_STATUS_BAR, !settings.showStatusBar) },
                onWallpaper = {
                    homeMenuOpen = false
                    context.startActivity(
                        Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Set wallpaper").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                onCustomize = { homeMenuOpen = false; settingsOpen = true },
                onDeviceSettings = { homeMenuOpen = false; context.openSystemSettings(android.provider.Settings.ACTION_SETTINGS) },
            )
        }

        // One-time nudge so the user can make this their real home app.
        if (!default.isDefault && settings.setupDone && !defaultPromptShown) {
            AlertDialog(
                onDismissRequest = { defaultPromptShown = true },
                title = { Text("Make Aurora your home app?") },
                text = { Text("Choose Aurora as your default launcher so the Home button and gestures open it.") },
                confirmButton = { TextButton(onClick = { defaultPromptShown = true; default.request() }) { Text("Choose") } },
                dismissButton = { TextButton(onClick = { defaultPromptShown = true }) { Text("Not now") } },
            )
        }
    }
}

/** The icon that follows the finger during a drag. Position is read in the layout phase only. */
@Composable
private fun DragGhost(drag: DragState, settings: LauncherSettings) {
    val payload = drag.payload ?: return
    val app: AppInfo? = when (payload) {
        is DragPayload.FromHome -> payload.app
        is DragPayload.FromDrawer -> payload.app
    }
    val size = settings.iconSizeDp.dp
    val half = with(LocalDensity.current) { (size / 2).roundToPx() }
    Box(
        Modifier
            .offset { IntOffset(drag.position.x.toInt() - half, drag.position.y.toInt() - half - 40) }
            .scale(1.12f)
            .shadow(14.dp, RoundedCornerShape(24.dp), clip = false)
    ) {
        if (app != null) IconArt(app, settings, size)
        else Box(Modifier.size(size).glass(RoundedCornerShape(30), strong = true))
    }
}

@Composable
private fun HomeMenu(
    settings: LauncherSettings,
    onDismiss: () -> Unit,
    onToggleSearch: () -> Unit,
    onToggleClock: () -> Unit,
    onToggleStatusBar: () -> Unit,
    onWallpaper: () -> Unit,
    onCustomize: () -> Unit,
    onDeviceSettings: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(28.dp)).padding(vertical = 8.dp)
        ) {
            MenuRow(
                icon = Icons.Outlined.Search,
                label = if (settings.showSearchBar) "Hide search bar" else "Show search bar",
                onClick = onToggleSearch
            )
            MenuRow(
                icon = Icons.Outlined.Schedule,
                label = if (settings.showClock) "Hide clock" else "Show clock",
                onClick = onToggleClock
            )
            MenuRow(
                icon = Icons.Outlined.Fullscreen,
                label = if (settings.showStatusBar) "Full screen (Hide status bar)" else "Show status bar",
                onClick = onToggleStatusBar
            )
            MenuRow(Icons.Outlined.Wallpaper, "Wallpaper", onWallpaper)
            MenuRow(Icons.Outlined.Palette, "Customize Aurora", onCustomize)
            MenuRow(Icons.Outlined.Settings, "Device settings", onDeviceSettings)
        }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

