package com.aurora.launcher.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

object Container {
    const val HOME = "home"
    const val DOCK = "dock"
    const val FOLDER = "folder"
}

object ItemType {
    const val APP = "app"
    const val FOLDER = "folder"
}

/**
 * One thing placed by the user: an app icon or a folder.
 * Home items use (page, cellX, cellY); dock items use cellX as their slot;
 * folder members use parentId + cellX as their order inside the folder.
 */
@Entity(tableName = "home_items")
data class HomeItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val container: String,
    val parentId: Long = 0,
    val page: Int = 0,
    val cellX: Int = 0,
    val cellY: Int = 0,
    val appKey: String? = null,
    val title: String? = null,
)

@Entity(tableName = "usage")
data class Usage(
    @PrimaryKey val appKey: String,
    val launches: Int,
    val lastLaunch: Long,
)

@Dao
interface HomeDao {
    @Query("SELECT * FROM home_items")
    fun observeAll(): Flow<List<HomeItem>>

    @Query("SELECT * FROM home_items")
    suspend fun getAll(): List<HomeItem>

    @Insert
    suspend fun insert(item: HomeItem): Long

    @Insert
    suspend fun insertAll(items: List<HomeItem>)

    @Update
    suspend fun update(item: HomeItem)

    @Update
    suspend fun updateAll(items: List<HomeItem>)

    @Query("DELETE FROM home_items WHERE id = :id OR parentId = :id")
    suspend fun deleteWithChildren(id: Long)

    @Query("DELETE FROM home_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM home_items")
    suspend fun clear()

    @Query("SELECT COUNT(*) FROM home_items")
    suspend fun count(): Int
}

@Dao
abstract class UsageDao {
    @Query("SELECT * FROM usage")
    abstract fun observeAll(): Flow<List<Usage>>

    @Query("SELECT * FROM usage WHERE appKey = :key")
    abstract suspend fun get(key: String): Usage?

    @Upsert
    abstract suspend fun upsert(usage: Usage)

    @Query("DELETE FROM usage")
    abstract suspend fun clear()

    @Transaction
    open suspend fun record(key: String, now: Long) {
        val current = get(key)
        upsert(Usage(key, (current?.launches ?: 0) + 1, now))
    }
}

@Database(entities = [HomeItem::class, Usage::class], version = 1, exportSchema = true)
abstract class LauncherDatabase : RoomDatabase() {
    abstract fun homeDao(): HomeDao
    abstract fun usageDao(): UsageDao

    companion object {
        fun create(context: Context): LauncherDatabase =
            Room.databaseBuilder(context, LauncherDatabase::class.java, "aurora.db").build()
    }
}
