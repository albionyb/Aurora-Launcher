package com.aurora.launcher.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.data.ThemeMode

/** Spacing scale used everywhere so layouts stay on one rhythm. */
object Space {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
}

/** Launcher-specific colors that sit on top of Material's scheme (glass surfaces). */
data class AuroraColors(
    val glass: Color,
    val glassStrong: Color,
    val onWallpaper: Color,
    val scrim: Color,
)

val LocalAurora = staticCompositionLocalOf {
    AuroraColors(Color.White, Color.White, Color.White, Color.Black)
}

private val AuroraShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(34.dp),
)

private val Sans = FontFamily.SansSerif

private val AuroraTypography = Typography(
    displayLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Light, fontSize = 72.sp, letterSpacing = (-2).sp),
    displayMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Light, fontSize = 52.sp, letterSpacing = (-1.5).sp),
    headlineMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 26.sp, letterSpacing = (-0.4).sp),
    titleLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 14.sp),
    labelLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 14.sp, letterSpacing = 0.1.sp),
    labelMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 12.sp, letterSpacing = 0.2.sp),
    labelSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.3.sp),
)

/** Builds a harmonious scheme from one accent color when dynamic color is off/unsupported. */
private fun schemeFromAccent(accent: Color, dark: Boolean): ColorScheme {
    val onAccent = if (accent.luminance() > 0.5f) Color(0xFF111118) else Color.White
    return if (dark) {
        val bg = Color(0xFF0F0F14)
        darkColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = accent.copy(alpha = 0.28f).compositeOver(bg),
            onPrimaryContainer = Color(0xFFEDEDF7),
            secondary = accent.copy(alpha = 0.75f).compositeOver(Color.White),
            background = bg,
            onBackground = Color(0xFFEDEDF4),
            surface = Color(0xFF17171E),
            onSurface = Color(0xFFEDEDF4),
            surfaceVariant = Color(0xFF23232D),
            onSurfaceVariant = Color(0xFFB4B4C4),
            outline = Color(0xFF4A4A58),
        )
    } else {
        val bg = Color(0xFFF7F7FB)
        lightColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = accent.copy(alpha = 0.16f).compositeOver(bg),
            onPrimaryContainer = Color(0xFF16161E),
            secondary = accent.copy(alpha = 0.8f).compositeOver(Color.Black),
            background = bg,
            onBackground = Color(0xFF16161E),
            surface = Color.White,
            onSurface = Color(0xFF16161E),
            surfaceVariant = Color(0xFFEBEBF3),
            onSurfaceVariant = Color(0xFF55556A),
            outline = Color(0xFFC4C4D2),
        )
    }
}

@Composable
fun AuroraTheme(settings: LauncherSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    val scheme = if (settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        schemeFromAccent(Color(settings.accent), dark)
    }
    val aurora = AuroraColors(
        glass = scheme.surface.copy(alpha = settings.glassAlpha),
        glassStrong = scheme.surface.copy(alpha = (settings.glassAlpha + 0.3f).coerceAtMost(0.96f)),
        // Text drawn straight over the wallpaper stays white; the dim scrim keeps it readable.
        onWallpaper = Color.White,
        scrim = Color.Black.copy(alpha = settings.dimAmount),
    )
    CompositionLocalProvider(LocalAurora provides aurora) {
        MaterialTheme(
            colorScheme = scheme,
            typography = AuroraTypography,
            shapes = AuroraShapes,
            content = content,
        )
    }
}
