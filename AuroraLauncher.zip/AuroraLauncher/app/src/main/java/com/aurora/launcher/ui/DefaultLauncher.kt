package com.aurora.launcher.ui

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

fun isDefaultLauncher(context: Context): Boolean {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    val match = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
    return match?.activityInfo?.packageName == context.packageName
}

private fun requestDefaultLauncher(context: Context, launcher: ActivityResultLauncher<Intent>) {
    // Android 10+: system role dialog. Older versions / unavailable role: the Home settings page.
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val roles = context.getSystemService(RoleManager::class.java)
        if (roles != null && roles.isRoleAvailable(RoleManager.ROLE_HOME) && !roles.isRoleHeld(RoleManager.ROLE_HOME)) {
            launcher.launch(roles.createRequestRoleIntent(RoleManager.ROLE_HOME))
            return
        }
    }
    try {
        context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

class DefaultLauncherController(val isDefault: Boolean, val request: () -> Unit)

/** Tracks whether we are the default home app and exposes the "make default" flow. */
@Composable
fun rememberDefaultLauncher(): DefaultLauncherController {
    val context = LocalContext.current
    var isDefault by remember { mutableStateOf(isDefaultLauncher(context)) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) isDefault = isDefaultLauncher(context)
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        isDefault = isDefaultLauncher(context)
    }
    return remember(isDefault) { DefaultLauncherController(isDefault) { requestDefaultLauncher(context, launcher) } }
}
