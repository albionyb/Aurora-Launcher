package com.aurora.launcher.data

import android.content.ComponentName
import android.content.pm.ApplicationInfo
import android.os.UserHandle

/** Coarse app grouping used by the drawer's category view. */
enum class AppCategory(val label: String) {
    GAMES("Games"),
    MEDIA("Media"),
    SOCIAL("Social"),
    PRODUCTIVITY("Productivity"),
    NEWS_MAPS("News & Maps"),
    OTHER("Other");

    companion object {
        /** Maps the framework [ApplicationInfo.category] value (API 26+) to our categories. */
        fun from(frameworkCategory: Int): AppCategory = when (frameworkCategory) {
            ApplicationInfo.CATEGORY_GAME -> GAMES
            ApplicationInfo.CATEGORY_AUDIO,
            ApplicationInfo.CATEGORY_VIDEO,
            ApplicationInfo.CATEGORY_IMAGE -> MEDIA
            ApplicationInfo.CATEGORY_SOCIAL -> SOCIAL
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> PRODUCTIVITY
            ApplicationInfo.CATEGORY_NEWS,
            ApplicationInfo.CATEGORY_MAPS -> NEWS_MAPS
            else -> OTHER
        }
    }
}

/**
 * A launchable activity discovered through LauncherApps.
 * [key] is stable across restarts and unique per profile (work profile apps differ).
 */
data class AppInfo(
    val key: String,
    val component: ComponentName,
    val user: UserHandle,
    val label: String,
    val installTime: Long,
    val category: AppCategory,
) {
    val packageName: String get() = component.packageName
}
