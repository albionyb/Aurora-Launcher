package com.aurora.launcher.ui.components

import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalHapticFeedback
import com.aurora.launcher.data.AppInfo
import com.aurora.launcher.data.HomeItem

/** What is currently being dragged. */
sealed interface DragPayload {
    /** An icon/folder that already lives on the home screen or in a folder. */
    data class FromHome(val item: HomeItem, val app: AppInfo?) : DragPayload

    /** An app dragged out of the drawer or search to be placed on the home screen. */
    data class FromDrawer(val app: AppInfo) : DragPayload
}

/**
 * Root-level drag state shared by every screen. Positions are in root coordinates, so the
 * dragged icon can float above whichever layer it started from.
 */
@Stable
class DragState {
    var payload by mutableStateOf<DragPayload?>(null)
        private set
    var position by mutableStateOf(Offset.Zero)
        private set

    /** Set by the home screen: resolves a drop position to a cell/dock slot and applies it. */
    var dropHandler: ((DragPayload, Offset) -> Unit)? = null

    val active: Boolean get() = payload != null
    val fromDrawer: Boolean get() = payload is DragPayload.FromDrawer

    fun start(p: DragPayload, at: Offset) {
        payload = p
        position = at
    }

    fun move(delta: Offset) {
        position += delta
    }

    fun end() {
        val p = payload
        if (p != null) dropHandler?.invoke(p, position)
        payload = null
    }

    fun cancel() {
        payload = null
    }
}

/**
 * Tap launches; long-press-and-release opens the menu; long-press-and-move starts a drag.
 * The drag only begins on the first movement so a plain long-press never floats an icon.
 */
@Composable
fun Modifier.dragSource(
    onTap: (Rect) -> Unit,
    onMenu: () -> Unit,
    onDragStart: (Offset) -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
): Modifier {
    var coords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    val tap by rememberUpdatedState(onTap)
    val menu by rememberUpdatedState(onMenu)
    val start by rememberUpdatedState(onDragStart)
    val drag by rememberUpdatedState(onDrag)
    val end by rememberUpdatedState(onDragEnd)
    val haptics = LocalHapticFeedback.current

    return this
        .onGloballyPositioned { coords = it }
        .pointerInput(Unit) {
            detectTapGestures(onTap = { coords?.let { c -> tap(c.boundsInRoot()) } })
        }
        .pointerInput(Unit) {
            var origin = Offset.Zero
            var dragging = false
            detectDragGesturesAfterLongPress(
                onDragStart = { local ->
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    origin = (coords?.positionInRoot() ?: Offset.Zero) + local
                    dragging = false
                },
                onDrag = { change, amount ->
                    change.consume()
                    if (!dragging) {
                        dragging = true
                        start(origin)
                    }
                    drag(amount)
                },
                onDragEnd = {
                    if (dragging) end() else menu()
                    dragging = false
                },
                onDragCancel = {
                    if (dragging) end()
                    dragging = false
                },
            )
        }
}
