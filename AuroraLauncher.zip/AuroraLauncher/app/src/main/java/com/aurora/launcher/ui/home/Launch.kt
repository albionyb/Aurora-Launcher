package com.aurora.launcher.ui.home

import android.os.Bundle
import android.view.View
import androidx.compose.ui.geometry.Rect
import com.aurora.launcher.data.AppRepository
import com.aurora.launcher.data.LaunchAnimation
import com.aurora.launcher.data.LauncherSettings

fun Rect.toAndroid(): android.graphics.Rect =
    android.graphics.Rect(left.toInt(), top.toInt(), right.toInt(), bottom.toInt())

/** Picks the activity-launch transition the user configured. */
fun launchOptions(settings: LauncherSettings, repo: AppRepository, view: View, bounds: Rect): Bundle? =
    when (settings.launchAnimation) {
        LaunchAnimation.ZOOM -> repo.scaleUpOptions(view, bounds.toAndroid())
        LaunchAnimation.FADE -> repo.fadeOptions()
        LaunchAnimation.NONE -> repo.noAnimationOptions()
    }
