package com.aurora.launcher.data

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.UserHandle
import android.os.UserManager
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Single source of truth for installed apps. Everything comes from [LauncherApps],
 * so work-profile apps, suspended apps and package changes are all handled by the system.
 */
class AppRepository(private val context: Context) {

    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val userManager = context.getSystemService(UserManager::class.java)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps

    /** True once the first scan finished, so the UI can tell "loading" from "no apps". */
    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded

    // Icons are kept as bitmaps; bounded by bytes so memory stays predictable.
    private val iconCache = object : LruCache<String, ImageBitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) = onChanged()
        override fun onPackageAdded(packageName: String?, user: UserHandle?) = onChanged()
        override fun onPackageChanged(packageName: String?, user: UserHandle?) = onChanged()
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = onChanged()
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = onChanged()
    }

    fun start() {
        launcherApps.registerCallback(callback)
        refresh()
    }

    private fun onChanged() {
        iconCache.evictAll()
        refresh()
    }

    fun refresh() {
        scope.launch {
            _apps.value = load()
            _loaded.value = true
        }
    }

    private fun load(): List<AppInfo> {
        val result = ArrayList<AppInfo>()
        for (user in userManager.userProfiles) {
            val serial = userManager.getSerialNumberForUser(user)
            for (info in launcherApps.getActivityList(null, user)) {
                if (info.componentName.packageName == context.packageName) continue // hide ourselves
                result += AppInfo(
                    key = keyOf(info.componentName, serial),
                    component = info.componentName,
                    user = user,
                    label = info.label?.toString().orEmpty(),
                    installTime = info.firstInstallTime,
                    category = AppCategory.from(info.applicationInfo.category),
                )
            }
        }
        return result.sortedBy { it.label.lowercase() }
    }

    private fun keyOf(component: ComponentName, serial: Long) = "${component.flattenToString()}#$serial"

    // ---------- Icons ----------

    /** Returns a cached icon bitmap, rendering it off the main thread on first use. */
    suspend fun icon(app: AppInfo): ImageBitmap {
        iconCache.get(app.key)?.let { return it }
        return withContext(Dispatchers.IO) {
            val drawable = launcherApps.getActivityList(app.packageName, app.user)
                .firstOrNull { it.componentName == app.component }
                ?.getIcon(0)
            val bitmap = render(drawable).asImageBitmap()
            iconCache.put(app.key, bitmap)
            bitmap
        }
    }

    /**
     * Adaptive icons are drawn as raw square layers (no system mask) so the launcher's
     * own icon shape can be applied in Compose. Legacy icons get a neutral backing.
     */
    private fun render(drawable: Drawable?): Bitmap {
        val s = ICON_PX
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        if (drawable == null) return out
        val canvas = Canvas(out)
        if (drawable is AdaptiveIconDrawable) {
            // Layers are 108dp with a 72dp visible window -> extend 25% beyond each edge.
            val pad = s / 4
            drawable.background?.let { it.setBounds(-pad, -pad, s + pad, s + pad); it.draw(canvas) }
            drawable.foreground?.let { it.setBounds(-pad, -pad, s + pad, s + pad); it.draw(canvas) }
        } else {
            canvas.drawColor(Color.argb(255, 242, 242, 247))
            val inset = (s * 0.16f).toInt()
            val bmp = drawable.toBitmap(s - inset * 2, s - inset * 2)
            canvas.drawBitmap(bmp, inset.toFloat(), inset.toFloat(), null)
        }
        return out
    }

    suspend fun shortcutIcon(shortcut: ShortcutInfo): ImageBitmap? = withContext(Dispatchers.IO) {
        try {
            launcherApps.getShortcutIconDrawable(shortcut, 0)?.toBitmap(96, 96)?.asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Actions ----------

    fun launch(app: AppInfo, sourceBounds: Rect?, options: Bundle?) {
        try {
            launcherApps.startMainActivity(app.component, app.user, sourceBounds, options)
        } catch (e: Exception) {
            // App was removed/disabled between listing and launch; refresh the list.
            refresh()
        }
    }

    fun openAppInfo(app: AppInfo) {
        try {
            launcherApps.startAppDetailsActivity(app.component, app.user, null, null)
        } catch (_: Exception) {
        }
    }

    fun uninstall(app: AppInfo) {
        val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    /** App shortcuts. Only available while we are the default launcher; otherwise empty. */
    fun shortcuts(app: AppInfo): List<ShortcutInfo> {
        if (!launcherApps.hasShortcutHostPermission()) return emptyList()
        return try {
            val query = LauncherApps.ShortcutQuery()
                .setPackage(app.packageName)
                .setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
                )
            launcherApps.getShortcuts(query, app.user).orEmpty().filter { it.isEnabled }.take(4)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun startShortcut(shortcut: ShortcutInfo) {
        try {
            launcherApps.startShortcut(shortcut, null, null)
        } catch (_: Exception) {
        }
    }

    /** Builds a scale-up launch animation from the tapped icon's on-screen bounds. */
    fun scaleUpOptions(window: android.view.View, bounds: Rect): Bundle =
        ActivityOptions.makeScaleUpAnimation(window, bounds.left, bounds.top, bounds.width(), bounds.height()).toBundle()

    fun fadeOptions(): Bundle =
        ActivityOptions.makeCustomAnimation(context, android.R.anim.fade_in, android.R.anim.fade_out).toBundle()

    fun noAnimationOptions(): Bundle =
        ActivityOptions.makeCustomAnimation(context, 0, 0).toBundle()

    companion object {
        private const val ICON_PX = 160
    }
}
