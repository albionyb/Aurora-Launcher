package com.aurora.launcher.ui.components

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurora.launcher.data.IconShape
import com.aurora.launcher.data.IconTheme
import com.aurora.launcher.ui.theme.LocalAurora
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

fun shapeFor(shape: IconShape): Shape = when (shape) {
    IconShape.CIRCLE -> CircleShape
    IconShape.SQUIRCLE -> RoundedCornerShape(32)
    IconShape.ROUNDED -> RoundedCornerShape(22)
    IconShape.SQUARE -> RoundedCornerShape(10)
    IconShape.TEARDROP -> RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 50, bottomStartPercent = 12)
}

/** Frosted surface used for the dock, search bar, folders and panels. */
@Composable
fun Modifier.glass(shape: Shape, strong: Boolean = false): Modifier {
    val a = LocalAurora.current
    return this
        .clip(shape)
        .background(if (strong) a.glassStrong else a.glass, shape)
        .border(0.6.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f), shape)
}

/** Grayscale or accent-tinted icon themes, applied as a color matrix (no re-rendering needed). */
@Composable
fun rememberIconFilter(theme: IconTheme): ColorFilter? {
    val primary = MaterialTheme.colorScheme.primary
    return when (theme) {
        IconTheme.ORIGINAL -> null
        IconTheme.GRAYSCALE -> ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
        IconTheme.TINTED -> {
            // out = luminance * accent, so every icon becomes a shade of the accent color.
            val lr = 0.213f; val lg = 0.715f; val lb = 0.072f
            val r = primary.red * 1.15f; val g = primary.green * 1.15f; val b = primary.blue * 1.15f
            ColorFilter.colorMatrix(
                ColorMatrix(
                    floatArrayOf(
                        lr * r, lg * r, lb * r, 0f, 0f,
                        lr * g, lg * g, lb * g, 0f, 0f,
                        lr * b, lg * b, lb * b, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f,
                    )
                )
            )
        }
    }
}

/** Large clock + date, ticking once per minute. */
@Composable
fun ClockWidget(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L))
        }
    }
    val pattern = if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm"
    val locale = Locale.getDefault()
    val color = LocalAurora.current.onWallpaper
    Column(modifier, horizontalAlignment = Alignment.Start) {
        Text(
            now.format(DateTimeFormatter.ofPattern(pattern, locale)),
            style = MaterialTheme.typography.displayMedium,
            color = color,
        )
        Text(
            now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", locale)),
            style = MaterialTheme.typography.titleMedium,
            color = color.copy(alpha = 0.85f),
        )
    }
}
