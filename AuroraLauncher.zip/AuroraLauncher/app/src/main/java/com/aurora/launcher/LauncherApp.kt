package com.aurora.launcher

import android.app.Application
import com.aurora.launcher.data.AppRepository
import com.aurora.launcher.data.LauncherDatabase
import com.aurora.launcher.data.SettingsRepository

/**
 * Application-scoped singletons. Kept manual (no DI framework) because the graph is tiny
 * and this keeps cold start fast and the dependency list short.
 */
class LauncherApp : Application() {
    lateinit var database: LauncherDatabase
        private set
    lateinit var settings: SettingsRepository
        private set
    lateinit var apps: AppRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = LauncherDatabase.create(this)
        settings = SettingsRepository(this)
        apps = AppRepository(this).also { it.start() }
    }
}
