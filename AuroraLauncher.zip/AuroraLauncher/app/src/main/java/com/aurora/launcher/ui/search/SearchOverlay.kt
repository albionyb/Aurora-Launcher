package com.aurora.launcher.ui.search

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.launcher.data.AppInfo
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.ui.LauncherViewModel
import com.aurora.launcher.ui.components.IconArt
import com.aurora.launcher.ui.components.appRepository
import com.aurora.launcher.ui.components.glass

/** A device settings page the search can jump straight to. */
data class QuickSetting(val label: String, val action: String, val keywords: String)

val quickSettings = listOf(
    QuickSetting("Wi-Fi", Settings.ACTION_WIFI_SETTINGS, "wifi wi-fi internet network"),
    QuickSetting("Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS, "bluetooth pair"),
    QuickSetting("Display", Settings.ACTION_DISPLAY_SETTINGS, "display brightness screen dark"),
    QuickSetting("Sound", Settings.ACTION_SOUND_SETTINGS, "sound volume ringtone audio"),
    QuickSetting("Battery", Settings.ACTION_BATTERY_SAVER_SETTINGS, "battery power saver"),
    QuickSetting("Storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS, "storage space memory"),
    QuickSetting("Apps", Settings.ACTION_APPLICATION_SETTINGS, "apps applications manage"),
    QuickSetting("Location", Settings.ACTION_LOCATION_SOURCE_SETTINGS, "location gps"),
    QuickSetting("Device settings", Settings.ACTION_SETTINGS, "settings system"),
)

fun Context.openSystemSettings(action: String) {
    try {
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
}

/** Lower is better: prefix of the label, then prefix of any word, then substring. */
private fun rank(label: String, q: String): Int {
    val l = label.lowercase()
    return when {
        l.startsWith(q) -> 0
        l.split(' ', '-', '.').any { it.startsWith(q) } -> 1
        l.contains(q) -> 2
        else -> 3
    }
}

@Composable
fun SearchOverlay(
    vm: LauncherViewModel,
    settings: LauncherSettings,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    val repo = context.appRepository()
    val apps by vm.drawerApps.collectAsStateWithLifecycle()
    val frequent by vm.frequentApps.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    val focus = LocalFocusManager.current
    val requester = remember { FocusRequester() }

    LaunchedEffect(Unit) { if (settings.searchAutoKeyboard) requester.requestFocus() }

    val q = query.trim().lowercase()
    val results = remember(q, apps) {
        if (q.isEmpty()) emptyList()
        else apps.map { it to rank(it.label, q) }.filter { it.second < 3 }
            .sortedWith(compareBy({ it.second }, { it.first.label.lowercase() })).map { it.first }
    }
    val settingMatches = remember(q) {
        if (q.isEmpty()) emptyList() else quickSettings.filter { (it.label + " " + it.keywords).lowercase().contains(q) }
    }

    fun launch(app: AppInfo) {
        vm.addRecentSearch(query.ifBlank { app.label })
        vm.launch(app, null, repo.fadeOptions())
        onClose()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.94f))
            .statusBarsPadding()
            .imePadding()
    ) {
        Column(Modifier.fillMaxSize().navigationBarsPadding()) {
            Row(
                Modifier
                    .padding(horizontal = 12.dp, vertical = 12.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(28.dp), strong = true)
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.AutoMirrored.Outlined.ArrowBack, "Back",
                    Modifier.clickable { focus.clearFocus(); onClose() }.padding(10.dp).size(22.dp),
                    tint = MaterialTheme.colorScheme.onSurface,
                )
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("Search apps and settings", color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyLarge)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = {
                            if (settings.searchLaunchSingle && results.isNotEmpty()) launch(results.first())
                            else focus.clearFocus()
                        }),
                        modifier = Modifier.fillMaxWidth().focusRequester(requester),
                    )
                }
                if (query.isNotEmpty()) Icon(
                    Icons.Outlined.Close, "Clear search",
                    Modifier.clickable { query = ""; requester.requestFocus() }.padding(10.dp).size(22.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)) {
                if (q.isEmpty()) {
                    // Idle state: recent searches, then suggestions.
                    if (settings.recentSearches.isNotEmpty()) {
                        item { SectionTitle("Recent", action = "Clear") { vm.clearRecentSearches() } }
                        items(settings.recentSearches, key = { "r_$it" }) { r ->
                            Row(
                                Modifier.fillMaxWidth().clickable { query = r }.padding(horizontal = 20.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Outlined.History, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("   $r", style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                    if (frequent.isNotEmpty()) {
                        item { SectionTitle("Suggested") }
                        items(frequent, key = { "f_${it.key}" }) { AppRow(it, settings) { launch(it) } }
                    }
                    item { SectionTitle("Quick settings") }
                    items(quickSettings.take(6), key = { "q_${it.action}" }) { s ->
                        SettingRow(s) { context.openSystemSettings(s.action); onClose() }
                    }
                } else {
                    items(results, key = { "a_${it.key}" }) { AppRow(it, settings) { launch(it) } }
                    if (settingMatches.isNotEmpty()) {
                        item { SectionTitle("Settings") }
                        items(settingMatches, key = { "s_${it.action}" }) { s ->
                            SettingRow(s) { vm.addRecentSearch(query); context.openSystemSettings(s.action); onClose() }
                        }
                    }
                    if (results.isEmpty() && settingMatches.isEmpty()) item {
                        Text(
                            "Nothing matches “${query.trim()}”",
                            Modifier.padding(32.dp).fillMaxWidth(),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null) Text(action, Modifier.clickable(onClick = onAction),
            style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun AppRow(app: AppInfo, settings: LauncherSettings, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconArt(app, settings, 44.dp)
        Text("   ${app.label}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun SettingRow(s: QuickSetting, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Outlined.Settings, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
        Text("   ${s.label}", style = MaterialTheme.typography.bodyLarge)
    }
}
