package com.aurora.launcher.ui.quick

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.launcher.data.AppInfo
import com.aurora.launcher.data.HAlign
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.data.QuickMaxApps
import com.aurora.launcher.data.QuickStyle
import com.aurora.launcher.ui.LauncherViewModel
import com.aurora.launcher.ui.components.IconArt
import com.aurora.launcher.ui.components.appRepository
import com.aurora.launcher.ui.components.glass
import com.aurora.launcher.ui.home.launchOptions
import com.aurora.launcher.ui.home.toAndroid
import com.aurora.launcher.ui.theme.LocalAurora
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private val ItemSize = 48.dp
private val OrbSize = 56.dp
private val EdgePad = 24.dp

/** Everything a style needs, so the three styles share one call shape. */
private class QuickArgs(
    val apps: List<AppInfo>,
    val settings: LauncherSettings,
    val open: Boolean,
    val master: Animatable<Float, AnimationVector1D>,
    val align: HAlign,
    val bottomPad: Dp,
    val speed: Float,
    val onSet: (Boolean) -> Unit,
    val onLaunch: (AppInfo, Rect) -> Unit,
)

/**
 * Animated quick-access shortcuts that stay collapsed until tapped, so the home screen stays clean.
 * Three styles share the same app list (max [QuickMaxApps]); see Customize > Quick access.
 */
@Composable
fun QuickAccess(
    vm: LauncherViewModel,
    settings: LauncherSettings,
    hidden: Boolean,
    modifier: Modifier = Modifier,
) {
    if (!settings.quickEnabled) return
    val appsByKey by vm.appsByKey.collectAsStateWithLifecycle()
    val fallback by vm.drawerApps.collectAsStateWithLifecycle()
    val apps = remember(settings.quickApps, appsByKey, fallback) {
        val picked = settings.quickApps.mapNotNull { appsByKey[it] }
        (if (picked.isEmpty()) fallback.take(5) else picked).take(QuickMaxApps)
    }
    if (apps.isEmpty()) return

    var open by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    val view = LocalView.current
    val haptic = LocalHapticFeedback.current
    val repo = remember { context.appRepository() }
    val speed = settings.animationSpeed

    LaunchedEffect(Unit) { vm.homePressed.collect { open = false } }
    LaunchedEffect(hidden) { if (hidden) open = false }
    BackHandler(enabled = open) { open = false }

    val master = remember { Animatable(0f) }
    LaunchedEffect(open, speed) {
        master.animateTo(
            if (open) 1f else 0f,
            spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow * speed),
        )
    }
    val scrim by animateFloatAsState(
        targetValue = if (open) 1f else 0f,
        animationSpec = tween((240 / speed).toInt().coerceAtLeast(60)),
        label = "quick-scrim",
    )
    if (hidden) return

    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    // Sit just above the dock (or the page dots) so nothing overlaps the dock icons.
    val bottomPad = navBottom + if (settings.showDock) (settings.iconSizeDp + 44 + 28).dp else 28.dp

    val args = QuickArgs(
        apps = apps, settings = settings, open = open, master = master,
        align = settings.quickAlign, bottomPad = bottomPad, speed = speed,
        onSet = { want ->
            if (settings.quickHaptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            open = want
        },
        onLaunch = { app, b ->
            open = false
            vm.launch(app, b.toAndroid(), launchOptions(settings, repo, view, b))
        },
    )

    Box(modifier.fillMaxSize()) {
        if (scrim > 0.01f) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.4f * scrim))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        args.onSet(false)
                    }
            )
        }
        when (settings.quickStyle) {
            QuickStyle.ORB -> OrbFan(args)
            QuickStyle.DOCK -> MorphDock(args)
            QuickStyle.DRAWER -> EdgeDrawer(args)
        }
    }
}

/** A springy 0..1 value per item. Items open in order and close in reverse, so it reads as one gesture. */
@Composable
private fun rememberStagger(open: Boolean, step: Int, stepMs: Long, speed: Float): Animatable<Float, AnimationVector1D> {
    val a = remember { Animatable(0f) }
    LaunchedEffect(open, speed) {
        delay((step * stepMs / speed).toLong())
        a.animateTo(
            if (open) 1f else 0f,
            spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow * speed),
        )
    }
    return a
}

private fun HAlign.bottomAlignment(): Alignment = when (this) {
    HAlign.LEFT -> Alignment.BottomStart
    HAlign.CENTER -> Alignment.BottomCenter
    HAlign.RIGHT -> Alignment.BottomEnd
}

@Composable
private fun QuickIcon(
    app: AppInfo,
    settings: LauncherSettings,
    size: Dp,
    enabled: Boolean,
    onLaunch: (AppInfo, Rect) -> Unit,
    modifier: Modifier = Modifier,
) {
    var bounds by remember { mutableStateOf(Rect.Zero) }
    Box(
        modifier
            .size(size)
            .onGloballyPositioned { bounds = it.boundsInRoot() }
            .clickable(
                enabled = enabled,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) { onLaunch(app, bounds) }
    ) {
        IconArt(app, settings, size)
    }
}

@Composable
private fun PlusIcon(master: Animatable<Float, AnimationVector1D>) {
    Icon(
        Icons.Outlined.Add, "Quick access",
        Modifier.size(28.dp).graphicsLayer { rotationZ = master.value * 135f },
        tint = LocalAurora.current.onWallpaper,
    )
}

// ---------------------------------------------------------------- Orb fan

@Composable
private fun BoxScope.OrbFan(a: QuickArgs) {
    val n = a.apps.size
    val inner = if (n <= 6) n else 5
    // Arc range in degrees: wide when centered, a quarter circle when tucked into a corner.
    val (from, to) = when (a.align) {
        HAlign.CENTER -> 160f to 20f
        HAlign.LEFT -> 85f to 8f
        HAlign.RIGHT -> 172f to 95f
    }
    val align = a.align.bottomAlignment()
    val ringGap = (OrbSize - ItemSize) / 2

    a.apps.forEachIndexed { i, app ->
        val ring = if (i < inner) 0 else 1
        val countInRing = if (ring == 0) inner else n - inner
        val idx = if (ring == 0) i else i - inner
        val t = if (countInRing == 1) 0.5f else idx / (countInRing - 1f)
        val rad = Math.toRadians((from + (to - from) * t).toDouble())
        val r = if (ring == 0) 96f else 164f
        val dx = (cos(rad) * r).toFloat()
        val dy = -(sin(rad) * r).toFloat()
        val p = rememberStagger(a.open, if (a.open) i else n - 1 - i, 38L, a.speed)

        QuickIcon(
            app, a.settings, ItemSize, a.open, a.onLaunch,
            Modifier
                .align(align)
                .padding(start = EdgePad + ringGap, end = EdgePad + ringGap, bottom = a.bottomPad + ringGap)
                .graphicsLayer {
                    val v = p.value
                    translationX = dx.dp.toPx() * v
                    translationY = dy.dp.toPx() * v
                    scaleX = v.coerceAtLeast(0f); scaleY = v.coerceAtLeast(0f)
                    alpha = v.coerceIn(0f, 1f)
                    rotationZ = (1f - v) * -90f
                },
        )
    }

    Box(
        Modifier
            .align(align)
            .padding(start = EdgePad, end = EdgePad, bottom = a.bottomPad)
            .size(OrbSize)
            .glass(CircleShape, strong = true, aurora = true)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { a.onSet(!a.open) },
        contentAlignment = Alignment.Center,
    ) { PlusIcon(a.master) }
}

// ---------------------------------------------------------------- Morph dock

@Composable
private fun BoxScope.MorphDock(a: QuickArgs) {
    val n = a.apps.size
    val maxW = LocalConfiguration.current.screenWidthDp.dp - 32.dp
    val full = minOf(OrbSize + (ItemSize + 8.dp) * n + 8.dp, maxW)

    Box(
        Modifier
            .align(a.align.bottomAlignment())
            .padding(horizontal = 16.dp)
            .padding(bottom = a.bottomPad)
            .layout { m, _ ->
                val w = (OrbSize.toPx() + (full - OrbSize).toPx() * a.master.value.coerceIn(0f, 1f)).roundToInt()
                val p = m.measure(Constraints.fixed(w, OrbSize.roundToPx()))
                layout(w, p.height) { p.place(0, 0) }
            }
            .glass(RoundedCornerShape(28.dp), strong = true, aurora = true)
    ) {
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(OrbSize)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { a.onSet(!a.open) },
                contentAlignment = Alignment.Center,
            ) { PlusIcon(a.master) }

            a.apps.forEachIndexed { i, app ->
                val p = rememberStagger(a.open, if (a.open) i else n - 1 - i, 55L, a.speed)
                QuickIcon(
                    app, a.settings, ItemSize, a.open, a.onLaunch,
                    Modifier
                        .padding(end = 8.dp)
                        .graphicsLayer {
                            val v = p.value
                            scaleX = v.coerceAtLeast(0f); scaleY = v.coerceAtLeast(0f)
                            alpha = v.coerceIn(0f, 1f)
                        },
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Edge drawer

@Composable
private fun BoxScope.EdgeDrawer(a: QuickArgs) {
    val right = a.align != HAlign.LEFT
    val side = if (right) Alignment.CenterEnd else Alignment.CenterStart
    val dir = if (right) 1f else -1f
    val panelW = 196.dp
    val n = a.apps.size

    Column(
        Modifier
            .align(side)
            .padding(horizontal = 30.dp)
            .width(panelW)
            .graphicsLayer {
                val p = a.master.value
                translationX = (1f - p) * (panelW.toPx() + 60.dp.toPx()) * dir
                alpha = (p * 1.5f).coerceIn(0f, 1f)
            }
            .glass(RoundedCornerShape(28.dp), strong = true, aurora = true)
            .heightIn(max = 460.dp)
            .verticalScroll(rememberScrollState())
            .padding(8.dp),
    ) {
        a.apps.forEachIndexed { i, app ->
            val p = rememberStagger(a.open, if (a.open) i else n - 1 - i, 50L, a.speed)
            var bounds by remember { mutableStateOf(Rect.Zero) }
            Row(
                Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned { bounds = it.boundsInRoot() }
                    .graphicsLayer {
                        val v = p.value
                        translationX = (1f - v) * 40.dp.toPx() * dir
                        alpha = v.coerceIn(0f, 1f)
                    }
                    .clip(RoundedCornerShape(18.dp))
                    .clickable(enabled = a.open) { a.onLaunch(app, bounds) }
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
            ) {
                IconArt(app, a.settings, 40.dp)
                Text(
                    app.label,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyLarge,
                    color = LocalAurora.current.onWallpaper,
                )
            }
        }
    }

    // The handle: tap it, or drag it inward, to open; drag outward to close.
    val idle = LocalAurora.current.onWallpaper.copy(alpha = 0.55f)
    val active = MaterialTheme.colorScheme.primary
    Box(
        Modifier
            .align(side)
            .width(28.dp)
            .height(96.dp)
            .pointerInput(right) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        val inward = if (right) -total else total
                        if (inward > 24f) a.onSet(true) else if (inward < -24f) a.onSet(false)
                    },
                    onHorizontalDrag = { _, dx -> total += dx },
                )
            }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { a.onSet(!a.open) },
        contentAlignment = if (right) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .width(6.dp)
                .height(56.dp)
                .graphicsLayer { scaleY = 1f - 0.35f * a.master.value.coerceIn(0f, 1f) }
                .clip(RoundedCornerShape(3.dp))
                .background(lerp(idle, active, a.master.value.coerceIn(0f, 1f)))
        )
    }
}
