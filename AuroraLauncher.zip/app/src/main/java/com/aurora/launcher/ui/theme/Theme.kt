package com.aurora.launcher.ui.theme

import android.os.Build
import android.app.WallpaperManager
import android.os.Handler
import android.os.Looper
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.data.ThemeMode

/** Spacing scale used everywhere so layouts stay on one rhythm. */
object Space {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
}

/** Launcher-specific colors that sit on top of Material's scheme (glass surfaces). */
data class AuroraColors(
    val glass: Color,
    val glassStrong: Color,
    val onWallpaper: Color,
    val scrim: Color,
    /** Three-stop aurora palette (taken from the wallpaper when adaptive colors are on). */
    val c1: Color = AuroraDefaults[0],
    val c2: Color = AuroraDefaults[1],
    val c3: Color = AuroraDefaults[2],
    val accentOn: Boolean = false,
    val glowOn: Boolean = false,
    val ribbonsOn: Boolean = false,
    val clockOn: Boolean = false,
    /** Slow 0..1..0 value that shifts the glow between c1 and c3. Read it only in draw scopes. */
    val phase: State<Float> = ConstantPhase,
) {
    val gradient: List<Color> get() = listOf(c1, c2, c3)
    fun glowColor(): Color = lerp(c1, c3, phase.value)
}

val AuroraDefaults = listOf(Color(0xFF3DDC97), Color(0xFF2BC4C4), Color(0xFF8A6BFF))
internal val ConstantPhase: State<Float> = mutableFloatStateOf(0f)

val LocalAurora = staticCompositionLocalOf {
    AuroraColors(Color.White, Color.White, Color.White, Color.Black)
}

/** Makes a wallpaper color bright and saturated enough to glow; [hueShift] spreads the three stops apart. */
private fun vivid(argb: Int, hueShift: Float = 0f): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(argb, hsv)
    hsv[0] = (hsv[0] + hueShift + 360f) % 360f
    hsv[1] = hsv[1].coerceAtLeast(0.55f)
    hsv[2] = hsv[2].coerceAtLeast(0.85f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/** Aurora palette from the current wallpaper (Android 8.1+), or the fixed aurora palette. */
@Composable
private fun rememberAuroraPalette(adaptive: Boolean): List<Color> {
    val context = LocalContext.current
    var colors by remember { mutableStateOf<List<Color>?>(null) }
    if (adaptive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
        DisposableEffect(Unit) {
            val wm = WallpaperManager.getInstance(context)
            fun load() {
                val wc = try { wm.getWallpaperColors(WallpaperManager.FLAG_SYSTEM) } catch (_: Throwable) { null }
                colors = wc?.let {
                    val p = it.primaryColor.toArgb()
                    val sec = it.secondaryColor?.toArgb()
                    val ter = it.tertiaryColor?.toArgb()
                    listOf(vivid(p), if (sec != null) vivid(sec) else vivid(p, 35f), if (ter != null) vivid(ter) else vivid(p, 70f))
                }
            }
            load()
            val listener = WallpaperManager.OnColorsChangedListener { _, _ -> load() }
            wm.addOnColorsChangedListener(listener, Handler(Looper.getMainLooper()))
            onDispose { wm.removeOnColorsChangedListener(listener) }
        }
    }
    return if (adaptive) colors ?: AuroraDefaults else AuroraDefaults
}

/** Material primary taken from the aurora palette, tuned for contrast in light and dark. */
private fun auroraPrimary(c: Color, dark: Boolean): Color {
    if (dark) return c
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    hsv[2] = (hsv[2] * 0.62f).coerceAtMost(0.6f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

private val AuroraShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(34.dp),
)

private val Sans = FontFamily.SansSerif

private val AuroraTypography = Typography(
    displayLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Light, fontSize = 72.sp, letterSpacing = (-2).sp),
    displayMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Light, fontSize = 52.sp, letterSpacing = (-1.5).sp),
    headlineMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 26.sp, letterSpacing = (-0.4).sp),
    titleLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 20.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 14.sp),
    labelLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 14.sp, letterSpacing = 0.1.sp),
    labelMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 12.sp, letterSpacing = 0.2.sp),
    labelSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.3.sp),
)

/** Builds a harmonious scheme from one accent color when dynamic color is off/unsupported. */
private fun schemeFromAccent(accent: Color, dark: Boolean): ColorScheme {
    val onAccent = if (accent.luminance() > 0.5f) Color(0xFF111118) else Color.White
    return if (dark) {
        val bg = Color(0xFF0F0F14)
        darkColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = accent.copy(alpha = 0.28f).compositeOver(bg),
            onPrimaryContainer = Color(0xFFEDEDF7),
            secondary = accent.copy(alpha = 0.75f).compositeOver(Color.White),
            background = bg,
            onBackground = Color(0xFFEDEDF4),
            surface = Color(0xFF17171E),
            onSurface = Color(0xFFEDEDF4),
            surfaceVariant = Color(0xFF23232D),
            onSurfaceVariant = Color(0xFFB4B4C4),
            outline = Color(0xFF4A4A58),
        )
    } else {
        val bg = Color(0xFFF7F7FB)
        lightColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = accent.copy(alpha = 0.16f).compositeOver(bg),
            onPrimaryContainer = Color(0xFF16161E),
            secondary = accent.copy(alpha = 0.8f).compositeOver(Color.Black),
            background = bg,
            onBackground = Color(0xFF16161E),
            surface = Color.White,
            onSurface = Color(0xFF16161E),
            surfaceVariant = Color(0xFFEBEBF3),
            onSurfaceVariant = Color(0xFF55556A),
            outline = Color(0xFFC4C4D2),
        )
    }
}

@Composable
fun AuroraTheme(settings: LauncherSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    val palette = rememberAuroraPalette(settings.adaptiveColors)
    val base = if (settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        schemeFromAccent(Color(settings.accent), dark)
    }
    val scheme = if (settings.auroraAccent) {
        val primary = auroraPrimary(palette[0], dark)
        base.copy(
            primary = primary,
            onPrimary = if (primary.luminance() > 0.5f) Color(0xFF111118) else Color.White,
            primaryContainer = primary.copy(alpha = 0.22f).compositeOver(base.surface),
            secondary = auroraPrimary(palette[1], dark),
        )
    } else base
    val phase: State<Float> = if (settings.auroraGlow) {
        rememberInfiniteTransition(label = "auroraPhase").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(5000, easing = LinearEasing), RepeatMode.Reverse),
            label = "phase",
        )
    } else ConstantPhase
    val aurora = AuroraColors(
        glass = scheme.surface.copy(alpha = settings.glassAlpha),
        glassStrong = scheme.surface.copy(alpha = (settings.glassAlpha + 0.3f).coerceAtMost(0.96f)),
        // Text drawn straight over the wallpaper stays white; the dim scrim keeps it readable.
        onWallpaper = Color.White,
        scrim = Color.Black.copy(alpha = settings.dimAmount),
        c1 = palette[0], c2 = palette[1], c3 = palette[2],
        accentOn = settings.auroraAccent,
        glowOn = settings.auroraGlow,
        ribbonsOn = settings.auroraRibbons,
        clockOn = settings.auroraClock,
        phase = phase,
    )
    CompositionLocalProvider(LocalAurora provides aurora) {
        MaterialTheme(
            colorScheme = scheme,
            typography = AuroraTypography,
            shapes = AuroraShapes,
            content = content,
        )
    }
}
