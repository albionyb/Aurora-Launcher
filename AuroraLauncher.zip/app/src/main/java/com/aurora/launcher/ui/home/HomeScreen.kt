package com.aurora.launcher.ui.home

import android.view.View
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import com.aurora.launcher.data.Container
import com.aurora.launcher.data.GestureAction
import com.aurora.launcher.data.HomeItem
import com.aurora.launcher.data.ItemType
import com.aurora.launcher.data.Keys
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.data.PageEffect
import com.aurora.launcher.ui.DropTarget
import com.aurora.launcher.ui.LauncherViewModel
import com.aurora.launcher.ui.components.AppIconView
import com.aurora.launcher.ui.components.ClockWidget
import com.aurora.launcher.ui.components.DragPayload
import com.aurora.launcher.ui.components.DragState
import com.aurora.launcher.ui.components.MenuAction
import com.aurora.launcher.ui.components.appRepository
import com.aurora.launcher.ui.components.glass
import com.aurora.launcher.ui.theme.LocalAurora
import kotlinx.coroutines.delay
import kotlin.math.abs

/** Screen rectangles recorded during layout, used to turn a finger position into a drop target. */
private class HomeBounds {
    val pages = HashMap<Int, Rect>()
    var dock: Rect? = null
    var remove: Rect? = null
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    vm: LauncherViewModel,
    settings: LauncherSettings,
    drag: DragState,
    onOpenSearch: () -> Unit,
    onOpenFolder: (folderId: Long, rename: Boolean) -> Unit,
    onHomeMenu: () -> Unit,
    onGesture: (GestureAction) -> Unit,
    modifier: Modifier = Modifier,
) {
    val items by vm.homeItems.collectAsStateWithLifecycle()
    val appsByKey by vm.appsByKey.collectAsStateWithLifecycle()
    val repo = LocalContext.current.appRepository()
    val view = LocalView.current
    val bounds = remember { HomeBounds() }

    val homeItems = remember(items) { items.filter { it.container == Container.HOME } }
    val dockItems = remember(items) { items.filter { it.container == Container.DOCK } }
    // While dragging, one extra empty page appears so an icon can start a new page.
    val pageCount = maxOf(1, (homeItems.maxOfOrNull { it.page } ?: 0) + 1) + if (drag.active) 1 else 0
    val pagerState = rememberPagerState(pageCount = { pageCount })

    // ----- Drop handling -----
    val resolve: (Offset) -> DropTarget? = { pos ->
        val dock = bounds.dock
        if (settings.showDock && dock != null && dock.contains(pos)) {
            DropTarget.DockSlot(((pos.x - dock.left) / dock.width * settings.dockCount).toInt().coerceIn(0, settings.dockCount - 1))
        } else {
            bounds.pages.entries.firstOrNull { it.value.contains(pos) }?.let { (page, r) ->
                DropTarget.HomeCell(
                    page,
                    ((pos.x - r.left) / r.width * settings.gridColumns).toInt().coerceIn(0, settings.gridColumns - 1),
                    ((pos.y - r.top) / r.height * settings.gridRows).toInt().coerceIn(0, settings.gridRows - 1),
                )
            }
        }
    }
    val resolveNow by rememberUpdatedState(resolve)
    DisposableEffect(drag) {
        drag.dropHandler = { payload, pos ->
            val inRemoveZone = bounds.remove?.contains(pos) == true
            if (inRemoveZone && payload is DragPayload.FromHome) {
                vm.removeItem(payload.item.id)
            } else {
                resolveNow(pos)?.let { target ->
                    when (payload) {
                        is DragPayload.FromHome -> vm.dropItem(payload.item.id, target)
                        is DragPayload.FromDrawer -> vm.dropApp(payload.app, target)
                    }
                }
            }
        }
        onDispose { drag.dropHandler = null }
    }
    val hover by remember { derivedStateOf { if (drag.active) resolveNow(drag.position) else null } }

    // ----- Edge hover flips pages while dragging -----
    val screenW = with(LocalDensity.current) { LocalConfiguration.current.screenWidthDp.dp.toPx() }
    val edge = with(LocalDensity.current) { 48.dp.toPx() }
    LaunchedEffect(drag.active) {
        while (drag.active) {
            val x = drag.position.x
            when {
                x < edge && pagerState.currentPage > 0 -> { pagerState.animateScrollToPage(pagerState.currentPage - 1); delay(650) }
                x > screenW - edge && pagerState.currentPage < pagerState.pageCount - 1 -> { pagerState.animateScrollToPage(pagerState.currentPage + 1); delay(650) }
                else -> delay(80)
            }
        }
    }
    LaunchedEffect(Unit) { vm.homePressed.collect { pagerState.animateScrollToPage(0) } }

    val gestureNow by rememberUpdatedState(onGesture)
    val settingsNow by rememberUpdatedState(settings)

    Box(
        modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                val threshold = 72.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total < -threshold) gestureNow(settingsNow.swipeUp)
                        else if (total > threshold) gestureNow(settingsNow.swipeDown)
                    },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            }
            .pinchIn { gestureNow(settingsNow.pinch) }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // Clock with quick 'X' close button to hide it instantly
            if (settings.showClock) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        ClockWidget()
                    }
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .clickable { vm.set(Keys.SHOW_CLOCK, false) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Outlined.Close,
                            contentDescription = "Hide clock",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        )
                    }
                }
            }

            if (settings.showSearchBar) {
                SearchPill(
                    onClick = onOpenSearch,
                    onClose = { vm.set(Keys.SHOW_SEARCH, false) }
                )
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp),
            ) { page ->
                val cellItems = remember(homeItems, page) {
                    homeItems.filter { it.page == page }.associateBy { it.cellX to it.cellY }
                }
                DisposableEffect(page) { onDispose { bounds.pages.remove(page) } }
                Column(
                    Modifier
                        .fillMaxSize()
                        .pageEffect(pagerState, page, settings.pageEffect)
                        .padding(horizontal = settings.sidePaddingDp.dp)
                        .onGloballyPositioned { bounds.pages[page] = it.boundsInRoot() }
                ) {
                    repeat(settings.gridRows) { y ->
                        Row(Modifier.weight(1f).fillMaxWidth()) {
                            repeat(settings.gridColumns) { x ->
                                val item = cellItems[x to y]
                                val isHover = hover == DropTarget.HomeCell(page, x, y)
                                Cell(
                                    modifier = Modifier.weight(1f),
                                    highlight = isHover,
                                    padV = (settings.rowSpacingDp / 2).dp,
                                    item = item,
                                    onHomeMenu = onHomeMenu,
                                    onDoubleTap = { gestureNow(settingsNow.doubleTap) },
                                ) { it ->
                                    ItemView(it, items, appsByKey, settings, vm, drag, repo, view, true, onOpenFolder)
                                }
                            }
                        }
                    }
                }
            }

            if (settings.pageIndicator && pageCount > 1) PageDots(pagerState, pageCount)

            if (settings.showDock) {
                val iconSize = settings.iconSizeDp.dp
                Row(
                    Modifier
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(34.dp))
                        .padding(horizontal = 8.dp, vertical = 10.dp)
                        .onGloballyPositioned { bounds.dock = it.boundsInRoot() }
                ) {
                    val bySlot = dockItems.associateBy { it.cellX }
                    repeat(settings.dockCount) { slot ->
                        Cell(
                            modifier = Modifier.weight(1f).height(iconSize + 8.dp),
                            highlight = hover == DropTarget.DockSlot(slot),
                            padV = 0.dp,
                            item = bySlot[slot],
                            onHomeMenu = onHomeMenu,
                            onDoubleTap = { gestureNow(settingsNow.doubleTap) },
                        ) { it ->
                            ItemView(it, items, appsByKey, settings, vm, drag, repo, view, false, onOpenFolder)
                        }
                    }
                }
            }
        }

        // Drop-to-remove zone, only visible while an icon from the home screen is being dragged.
        if (drag.payload is DragPayload.FromHome) RemoveZone(drag, bounds)
    }
}

/** Isolated so only this small tree recomposes as the finger moves. */
@Composable
private fun RemoveZone(drag: DragState, bounds: HomeBounds) {
    Box(
        Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp),
        contentAlignment = Alignment.TopCenter,
    ) {
        val over = bounds.remove?.contains(drag.position) == true
        Row(
            Modifier
                .glass(RoundedCornerShape(28.dp), strong = over)
                .onGloballyPositioned { bounds.remove = it.boundsInRoot() }
                .padding(horizontal = 24.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.Close, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurface)
            Text("  Remove", color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Cell(
    modifier: Modifier,
    highlight: Boolean,
    padV: androidx.compose.ui.unit.Dp,
    item: HomeItem?,
    onHomeMenu: () -> Unit,
    onDoubleTap: () -> Unit,
    content: @Composable (HomeItem) -> Unit,
) {
    Box(
        modifier
            .fillMaxHeight()
            .padding(vertical = padV)
            .clip(RoundedCornerShape(20.dp))
            .background(if (highlight) MaterialTheme.colorScheme.primary.copy(alpha = 0.28f) else androidx.compose.ui.graphics.Color.Transparent)
            .then(
                if (item == null) Modifier.combinedClickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {},
                    onLongClick = onHomeMenu,
                    onDoubleClick = onDoubleTap,
                ) else Modifier
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (item != null) content(item)
    }
}

/** Renders an app or folder item with its menu and drag wiring. */
@Composable
private fun ItemView(
    item: HomeItem,
    allItems: List<HomeItem>,
    appsByKey: Map<String, com.aurora.launcher.data.AppInfo>,
    settings: LauncherSettings,
    vm: LauncherViewModel,
    drag: DragState,
    repo: com.aurora.launcher.data.AppRepository,
    view: View,
    showLabel: Boolean,
    onOpenFolder: (Long, Boolean) -> Unit,
) {
    val draggedId = (drag.payload as? DragPayload.FromHome)?.item?.id
    val dimmed = draggedId == item.id
    val labels = showLabel && settings.showLabels
    if (item.type == ItemType.FOLDER) {
        val members = remember(allItems, appsByKey, item.id) {
            allItems.filter { it.container == Container.FOLDER && it.parentId == item.id }
                .sortedBy { it.cellX }.mapNotNull { appsByKey[it.appKey] }
        }
        com.aurora.launcher.ui.home.FolderIconView(
            folder = item, members = members, settings = settings, drag = drag,
            showLabel = labels, dimmed = dimmed,
            onOpen = { onOpenFolder(item.id, false) },
            onRename = { onOpenFolder(item.id, true) },
            onRemove = { vm.removeItem(item.id) },
        )
    } else {
        val app = appsByKey[item.appKey] ?: return
        AppIconView(
            app = app, settings = settings, drag = drag,
            payload = DragPayload.FromHome(item, app),
            showLabel = labels, dimmed = dimmed,
            actions = listOf(
                MenuAction("Remove", Icons.Outlined.Close) { vm.removeItem(item.id) },
                MenuAction("App info", Icons.Outlined.Info) { repo.openAppInfo(app) },
                MenuAction("Uninstall", Icons.Outlined.Delete) { repo.uninstall(app) },
            ),
            onLaunch = { b -> vm.launch(app, b.toAndroid(), launchOptions(settings, repo, view, b)) },
        )
    }
}

@Composable
private fun SearchPill(onClick: () -> Unit, onClose: () -> Unit) {
    Row(
        Modifier
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .fillMaxWidth()
            .glass(RoundedCornerShape(28.dp))
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .clickable(onClick = onClick),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.Search, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "  Search apps",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyLarge,
            )
        }
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .clickable(onClick = onClose),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Outlined.Close,
                contentDescription = "Remove search bar",
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun PageDots(state: PagerState, count: Int) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
    ) {
        repeat(count) { i ->
            val selected = state.currentPage == i
            val w by animateDpAsState(if (selected) 18.dp else 6.dp, label = "dot")
            Box(
                Modifier
                    .padding(horizontal = 3.dp)
                    .height(6.dp)
                    .width(w)
                    .clip(CircleShape)
                    .background(LocalAurora.current.onWallpaper.copy(alpha = if (selected) 0.95f else 0.45f))
            )
        }
    }
}

/** Page-scroll visual effect chosen in settings. Runs in the draw phase only. */
private fun Modifier.pageEffect(state: PagerState, page: Int, effect: PageEffect): Modifier =
    if (effect == PageEffect.SLIDE) this else graphicsLayer {
        val offset = (state.currentPage - page) + state.currentPageOffsetFraction
        val a = abs(offset).coerceIn(0f, 1f)
        when (effect) {
            PageEffect.FADE_SCALE -> {
                alpha = 1f - a * 0.65f
                scaleX = 1f - 0.12f * a
                scaleY = 1f - 0.12f * a
            }
            PageEffect.ROTATE -> {
                cameraDistance = 14f * density
                rotationY = offset * -32f
                alpha = 1f - a * 0.5f
            }
            PageEffect.SLIDE -> Unit
        }
    }

/** Fires once when two fingers move together (pinch-in). Observes without consuming events. */
private fun Modifier.pinchIn(onPinch: () -> Unit): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        var startDistance = 0f
        var fired = false
        do {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val pressed = event.changes.filter { it.pressed }
            if (pressed.size >= 2 && !fired) {
                val d = (pressed[0].position - pressed[1].position).getDistance()
                if (startDistance == 0f) startDistance = d
                else if (d < startDistance * 0.75f) {
                    fired = true
                    onPinch()
                }
            }
        } while (event.changes.any { it.pressed })
    }
}
