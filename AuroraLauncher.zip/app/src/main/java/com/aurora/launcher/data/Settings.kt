package com.aurora.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class IconShape { CIRCLE, SQUIRCLE, ROUNDED, TEARDROP, SQUARE }
enum class IconTheme { ORIGINAL, GRAYSCALE, TINTED }
enum class DrawerSort { AZ, ZA, NEWEST, MOST_USED }
enum class GestureAction(val label: String) {
    NONE("Nothing"),
    OPEN_DRAWER("Open app drawer"),
    OPEN_SEARCH("Open search"),
    OPEN_NOTIFICATIONS("Pull down notifications"),
    OPEN_SETTINGS("Launcher settings"),
}
enum class LaunchAnimation { ZOOM, FADE, NONE }
enum class FolderStyle { ROUNDED, CIRCLE }
enum class PageEffect(val label: String) { SLIDE("Slide"), FADE_SCALE("Fade & scale"), ROTATE("Rotate") }

/** Immutable snapshot of every user preference. Defaults live here, in one place. */
data class LauncherSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val accent: Int = 0xFF5B5BD6.toInt(),
    val dimAmount: Float = 0.25f,
    val blurWallpaper: Boolean = true,
    val glassAlpha: Float = 0.55f,

    val iconSizeDp: Int = 58,
    val iconShape: IconShape = IconShape.SQUIRCLE,
    val iconTheme: IconTheme = IconTheme.ORIGINAL,
    val showLabels: Boolean = true,
    val labelSizeSp: Int = 12,
    val labelBold: Boolean = false,

    val gridColumns: Int = 4,
    val gridRows: Int = 5,
    val showDock: Boolean = true,
    val dockCount: Int = 4,
    val pageIndicator: Boolean = true,
    val sidePaddingDp: Int = 12,
    val rowSpacingDp: Int = 8,
    val showSearchBar: Boolean = true,
    val showClock: Boolean = true,
    val showStatusBar: Boolean = true,
    val folderStyle: FolderStyle = FolderStyle.ROUNDED,
    val pageEffect: PageEffect = PageEffect.FADE_SCALE,

    val drawerColumns: Int = 4,
    val drawerSort: DrawerSort = DrawerSort.AZ,
    val drawerCategories: Boolean = false,
    val drawerSuggestions: Boolean = true,
    val searchAutoKeyboard: Boolean = true,
    val searchLaunchSingle: Boolean = true,

    val swipeUp: GestureAction = GestureAction.OPEN_DRAWER,
    val swipeDown: GestureAction = GestureAction.OPEN_NOTIFICATIONS,
    val doubleTap: GestureAction = GestureAction.NONE,
    val pinch: GestureAction = GestureAction.OPEN_SETTINGS,

    val launchAnimation: LaunchAnimation = LaunchAnimation.ZOOM,
    val animationSpeed: Float = 1f,

    val hiddenApps: Set<String> = emptySet(),
    val recentSearches: List<String> = emptyList(),
    val setupDone: Boolean = false,

    // Aurora look
    val adaptiveColors: Boolean = true,
    val auroraAccent: Boolean = true,
    val auroraGlow: Boolean = true,
    val auroraRibbons: Boolean = true,
    val auroraClock: Boolean = true,
    val iconShimmer: Boolean = true,
    val introAnimation: Boolean = true,
    val introSeen: Boolean = true,
)

private val Context.dataStore by preferencesDataStore(name = "aurora_settings")

object Keys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
    val ACCENT = intPreferencesKey("accent")
    val DIM = floatPreferencesKey("dim")
    val BLUR = booleanPreferencesKey("blur")
    val GLASS = floatPreferencesKey("glass")
    val ICON_SIZE = intPreferencesKey("icon_size")
    val ICON_SHAPE = stringPreferencesKey("icon_shape")
    val ICON_THEME = stringPreferencesKey("icon_theme")
    val SHOW_LABELS = booleanPreferencesKey("show_labels")
    val LABEL_SIZE = intPreferencesKey("label_size")
    val LABEL_BOLD = booleanPreferencesKey("label_bold")
    val GRID_COLS = intPreferencesKey("grid_cols")
    val GRID_ROWS = intPreferencesKey("grid_rows")
    val SHOW_DOCK = booleanPreferencesKey("show_dock")
    val DOCK_COUNT = intPreferencesKey("dock_count")
    val PAGE_INDICATOR = booleanPreferencesKey("page_indicator")
    val SIDE_PADDING = intPreferencesKey("side_padding")
    val ROW_SPACING = intPreferencesKey("row_spacing")
    val SHOW_SEARCH = booleanPreferencesKey("show_search")
    val SHOW_CLOCK = booleanPreferencesKey("show_clock")
    val SHOW_STATUS_BAR = booleanPreferencesKey("show_status_bar")
    val FOLDER_STYLE = stringPreferencesKey("folder_style")
    val PAGE_EFFECT = stringPreferencesKey("page_effect")
    val DRAWER_COLS = intPreferencesKey("drawer_cols")
    val DRAWER_SORT = stringPreferencesKey("drawer_sort")
    val DRAWER_CATEGORIES = booleanPreferencesKey("drawer_categories")
    val DRAWER_SUGGESTIONS = booleanPreferencesKey("drawer_suggestions")
    val SEARCH_KEYBOARD = booleanPreferencesKey("search_keyboard")
    val SEARCH_LAUNCH_SINGLE = booleanPreferencesKey("search_launch_single")
    val SWIPE_UP = stringPreferencesKey("swipe_up")
    val SWIPE_DOWN = stringPreferencesKey("swipe_down")
    val DOUBLE_TAP = stringPreferencesKey("double_tap")
    val PINCH = stringPreferencesKey("pinch")
    val LAUNCH_ANIM = stringPreferencesKey("launch_anim")
    val ANIM_SPEED = floatPreferencesKey("anim_speed")
    val HIDDEN = stringSetPreferencesKey("hidden_apps")
    val RECENT_SEARCHES = stringPreferencesKey("recent_searches")
    val SETUP_DONE = booleanPreferencesKey("setup_done")
    val ADAPTIVE_COLORS = booleanPreferencesKey("adaptive_colors")
    val AURORA_ACCENT = booleanPreferencesKey("aurora_accent")
    val AURORA_GLOW = booleanPreferencesKey("aurora_glow")
    val AURORA_RIBBONS = booleanPreferencesKey("aurora_ribbons")
    val AURORA_CLOCK = booleanPreferencesKey("aurora_clock")
    val ICON_SHIMMER = booleanPreferencesKey("icon_shimmer")
    val INTRO_ANIM = booleanPreferencesKey("intro_anim")
    val INTRO_SEEN = booleanPreferencesKey("intro_seen")
}

/** Wraps DataStore. Every setting is persisted immediately and survives process death[span_1](start_span)[span_1](end_span). */
class SettingsRepository(private val context: Context) {

    val settings: Flow<LauncherSettings> = context.dataStore.data.map { p -> p.toSettings() }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        context.dataStore.edit { it[key] = value }
    }

    suspend fun setHidden(key: String, hidden: Boolean) {
        context.dataStore.edit { p ->
            val cur = p[Keys.HIDDEN].orEmpty()
            p[Keys.HIDDEN] = if (hidden) cur + key else cur - key
        }
    }

    suspend fun addRecentSearch(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        context.dataStore.edit { p ->
            val list = p[Keys.RECENT_SEARCHES].orEmpty().split('\n').filter { it.isNotBlank() && it != q }
            p[Keys.RECENT_SEARCHES] = (listOf(q) + list).take(8).joinToString("\n")
        }
    }

    suspend fun clearRecentSearches() {
        context.dataStore.edit { it[Keys.RECENT_SEARCHES] = "" }
    }

    suspend fun resetAll() {
        context.dataStore.edit { it.clear() }
    }

    /** Raw snapshot for backup/restore[span_2](start_span)[span_2](end_span). */
    suspend fun snapshot(): Map<String, Any> =
        context.dataStore.data.first().asMap().mapKeys { it.key.name }

    /** Replaces all preferences with values from a backup[span_3](start_span)[span_3](end_span). */
    suspend fun restore(values: Map<String, Any>) {
        context.dataStore.edit { p ->
            p.clear()
            for ((name, v) in values) when (v) {
                is Boolean -> p[booleanPreferencesKey(name)] = v
                is Int -> p[intPreferencesKey(name)] = v
                is Float -> p[floatPreferencesKey(name)] = v
                is String -> p[stringPreferencesKey(name)] = v
                is Set<*> -> p[stringSetPreferencesKey(name)] = v.filterIsInstance<String>().toSet()
            }
        }
    }

    private inline fun <reified E : Enum<E>> Preferences.enum(key: Preferences.Key<String>, default: E): E =
        this[key]?.let { v -> enumValues<E>().firstOrNull { it.name == v } } ?: default

    private fun Preferences.toSettings(): LauncherSettings {
        val d = LauncherSettings()
        return LauncherSettings(
            themeMode = enum(Keys.THEME_MODE, d.themeMode),
            dynamicColor = this[Keys.DYNAMIC_COLOR] ?: d.dynamicColor,
            accent = this[Keys.ACCENT] ?: d.accent,
            dimAmount = this[Keys.DIM] ?: d.dimAmount,
            blurWallpaper = this[Keys.BLUR] ?: d.blurWallpaper,
            glassAlpha = this[Keys.GLASS] ?: d.glassAlpha,
            iconSizeDp = this[Keys.ICON_SIZE] ?: d.iconSizeDp,
            iconShape = enum(Keys.ICON_SHAPE, d.iconShape),
            iconTheme = enum(Keys.ICON_THEME, d.iconTheme),
            showLabels = this[Keys.SHOW_LABELS] ?: d.showLabels,
            labelSizeSp = this[Keys.LABEL_SIZE] ?: d.labelSizeSp,
            labelBold = this[Keys.LABEL_BOLD] ?: d.labelBold,
            gridColumns = this[Keys.GRID_COLS] ?: d.gridColumns,
            gridRows = this[Keys.GRID_ROWS] ?: d.gridRows,
            showDock = this[Keys.SHOW_DOCK] ?: d.showDock,
            dockCount = this[Keys.DOCK_COUNT] ?: d.dockCount,
            pageIndicator = this[Keys.PAGE_INDICATOR] ?: d.pageIndicator,
            sidePaddingDp = this[Keys.SIDE_PADDING] ?: d.sidePaddingDp,
            rowSpacingDp = this[Keys.ROW_SPACING] ?: d.rowSpacingDp,
            showSearchBar = this[Keys.SHOW_SEARCH] ?: d.showSearchBar,
            showClock = this[Keys.SHOW_CLOCK] ?: d.showClock,
            showStatusBar = this[Keys.SHOW_STATUS_BAR] ?: d.showStatusBar,
            folderStyle = enum(Keys.FOLDER_STYLE, d.folderStyle),
            pageEffect = enum(Keys.PAGE_EFFECT, d.pageEffect),
            drawerColumns = this[Keys.DRAWER_COLS] ?: d.drawerColumns,
            drawerSort = enum(Keys.DRAWER_SORT, d.drawerSort),
            drawerCategories = this[Keys.DRAWER_CATEGORIES] ?: d.drawerCategories,
            drawerSuggestions = this[Keys.DRAWER_SUGGESTIONS] ?: d.drawerSuggestions,
            searchAutoKeyboard = this[Keys.SEARCH_KEYBOARD] ?: d.searchAutoKeyboard,
            searchLaunchSingle = this[Keys.SEARCH_LAUNCH_SINGLE] ?: d.searchLaunchSingle,
            swipeUp = enum(Keys.SWIPE_UP, d.swipeUp),
            swipeDown = enum(Keys.SWIPE_DOWN, d.swipeDown),
            doubleTap = enum(Keys.DOUBLE_TAP, d.doubleTap),
            pinch = enum(Keys.PINCH, d.pinch),
            launchAnimation = enum(Keys.LAUNCH_ANIM, d.launchAnimation),
            animationSpeed = this[Keys.ANIM_SPEED] ?: d.animationSpeed,
            hiddenApps = this[Keys.HIDDEN].orEmpty(),
            recentSearches = this[Keys.RECENT_SEARCHES].orEmpty().split('\n').filter { it.isNotBlank() },
            setupDone = this[Keys.SETUP_DONE] ?: d.setupDone,
            adaptiveColors = this[Keys.ADAPTIVE_COLORS] ?: d.adaptiveColors,
            auroraAccent = this[Keys.AURORA_ACCENT] ?: d.auroraAccent,
            auroraGlow = this[Keys.AURORA_GLOW] ?: d.auroraGlow,
            auroraRibbons = this[Keys.AURORA_RIBBONS] ?: d.auroraRibbons,
            auroraClock = this[Keys.AURORA_CLOCK] ?: d.auroraClock,
            iconShimmer = this[Keys.ICON_SHIMMER] ?: d.iconShimmer,
            introAnimation = this[Keys.INTRO_ANIM] ?: d.introAnimation,
            introSeen = this[Keys.INTRO_SEEN] ?: d.introSeen,
        )
    }
}

