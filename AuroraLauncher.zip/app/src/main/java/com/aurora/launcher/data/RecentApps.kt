package com.aurora.launcher.data

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process

/** True when the user granted "Usage access" to Aurora (needed to know which apps were used recently). */
fun hasUsageAccess(context: Context): Boolean {
    val ops = context.getSystemService(AppOpsManager::class.java) ?: return false
    val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
    } else {
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
    }
    return mode == AppOpsManager.MODE_ALLOWED
}

/**
 * Apps the user closed from Aurora's recents, with the time they were closed. The usage log still
 * says "used in the last 24 h" after a close, so without this a closed app would reappear at once.
 * It shows up again only after it comes to the foreground again.
 */
object ClosedApps {
    private val closedAt = HashMap<String, Long>()
    @Synchronized fun mark(pkg: String) { closedAt[pkg] = System.currentTimeMillis() }
    @Synchronized fun isClosed(pkg: String, lastUsed: Long): Boolean = closedAt[pkg]?.let { lastUsed <= it } ?: false
}

/** Package names of apps used in the last 24 h, most recent first (Aurora itself excluded). */
@Suppress("DEPRECATION")
fun recentPackages(context: Context): List<String> {
    val usm = context.getSystemService(UsageStatsManager::class.java) ?: return emptyList()
    val now = System.currentTimeMillis()
    val events = try {
        usm.queryEvents(now - 24L * 60 * 60 * 1000, now)
    } catch (_: Exception) {
        return emptyList()
    }
    val last = HashMap<String, Long>()
    val e = UsageEvents.Event()
    while (events.hasNextEvent()) {
        events.getNextEvent(e)
        if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && e.packageName != context.packageName) {
            last[e.packageName] = e.timeStamp
        }
    }
    return last.entries.filter { !ClosedApps.isClosed(it.key, it.value) }.sortedByDescending { it.value }.map { it.key }
}

/**
 * Stops an app's processes. Android only lets a normal app kill cached/background processes, and some
 * phones restart them right away, so the kill is repeated once after a short delay. An app with a
 * running foreground service (music, downloads) can only be stopped from its App info page.
 */
fun killApp(context: Context, packageName: String) {
    ClosedApps.mark(packageName)
    val am = context.getSystemService(ActivityManager::class.java) ?: return
    fun kill() {
        try { am.killBackgroundProcesses(packageName) } catch (_: Exception) { }
    }
    kill()
    Handler(Looper.getMainLooper()).postDelayed({ kill() }, 400)
}
