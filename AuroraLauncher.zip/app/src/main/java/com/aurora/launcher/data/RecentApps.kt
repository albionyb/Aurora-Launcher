package com.aurora.launcher.data

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process

/** True when the user granted "Usage access" to Aurora (needed to know which apps were used recently). */
fun hasUsageAccess(context: Context): Boolean {
    val ops = context.getSystemService(AppOpsManager::class.java) ?: return false
    val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
    } else {
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
    }
    return mode == AppOpsManager.MODE_ALLOWED
}

/** Package names of apps used in the last 24 h, most recent first (Aurora itself excluded). */
@Suppress("DEPRECATION")
fun recentPackages(context: Context): List<String> {
    val usm = context.getSystemService(UsageStatsManager::class.java) ?: return emptyList()
    val now = System.currentTimeMillis()
    val events = try {
        usm.queryEvents(now - 24L * 60 * 60 * 1000, now)
    } catch (_: Exception) {
        return emptyList()
    }
    val last = HashMap<String, Long>()
    val e = UsageEvents.Event()
    while (events.hasNextEvent()) {
        events.getNextEvent(e)
        if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && e.packageName != context.packageName) {
            last[e.packageName] = e.timeStamp
        }
    }
    return last.entries.sortedByDescending { it.value }.map { it.key }
}

/** Stops an app's background processes. Works for apps that are not in the foreground. */
fun killApp(context: Context, packageName: String) {
    try {
        context.getSystemService(ActivityManager::class.java)?.killBackgroundProcesses(packageName)
    } catch (_: Exception) {
    }
}
