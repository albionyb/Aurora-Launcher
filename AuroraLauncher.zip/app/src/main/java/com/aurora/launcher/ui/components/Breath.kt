package com.aurora.launcher.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.aurora.launcher.data.BreathMaxSpots
import com.aurora.launcher.data.BreathSpot
import com.aurora.launcher.data.BreathTint
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.ui.theme.LocalAurora
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin

private const val Puffs = 6
private const val EmitSeconds = 2.6f
private const val PuffLife = 6.5f
private const val Lumps = 5

private fun hash(n: Int): Float {
    val v = sin(n * 12.9898f) * 43758.547f
    return v - floor(v)
}

private fun tintColor(tint: BreathTint, c1: Color): Color = when (tint) {
    BreathTint.FROST -> Color(0xFFD6EEFF)
    BreathTint.WHITE -> Color.White
    BreathTint.AURORA -> c1
}

/**
 * Cold breath: soft puffs of vapor exhaled from each spot, drifting along its angle, growing and fading.
 * With auto hide on, each spot rests for a few seconds, then breathes again from a slightly different direction.
 * Draw-only animation: the clock is read inside the Canvas, so nothing recomposes per frame.
 */
@Composable
fun ColdBreath(settings: LauncherSettings, spots: List<BreathSpot> = settings.breathSpots, modifier: Modifier = Modifier) {
    if (!settings.breathEnabled || spots.isEmpty()) return
    val aurora = LocalAurora.current
    val color = tintColor(settings.breathTint, aurora.c1)
    var time by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var start = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { n ->
                if (start == 0L) start = n
                time = (n - start) / 1_000_000_000f
            }
        }
    }
    val gap = if (settings.breathAutoHide) settings.breathInterval.coerceAtLeast(1f) else 0.4f
    val period = EmitSeconds + PuffLife + gap
    val intensity = settings.breathIntensity

    Canvas(modifier.fillMaxSize()) {
        val t = time
        spots.forEachIndexed { si, spot ->
            val local = t + si * 1.9f
            val cycle = floor(local / period).toInt()
            val tau = local - cycle * period
            val seed = cycle * 31 + si * 7
            val angle = spot.angle + (hash(seed) - 0.5f) * 24f
            drawBreath(spot, angle, tau, seed, color, intensity)
        }
    }
}

private fun DrawScope.drawBreath(spot: BreathSpot, angleDeg: Float, tau: Float, seed: Int, color: Color, intensity: Float) {
    val d = density
    val rad = angleDeg * (PI.toFloat() / 180f)
    val dx = cos(rad)
    val dy = sin(rad)
    val origin = Offset(spot.x * size.width, spot.y * size.height)
    val reach = 80f * d * spot.scale
    for (i in 0 until Puffs) {
        val age = (tau - i * (EmitSeconds / Puffs)) / PuffLife
        if (age <= 0f || age >= 1f) continue
        val h = hash(seed * 17 + i)
        // Starts moving a little, then slows to a hang: a cloud, not a jet.
        val ease = 1f - (1f - age) * (1f - age) * (1f - age)
        val drift = sin(age * 3f + h * 6f) * 6f * d * spot.scale
        val rise = -age * 22f * d * spot.scale
        val cx = origin.x + dx * reach * ease * (0.7f + 0.4f * h) - dy * drift
        val cy = origin.y + dy * reach * ease * (0.7f + 0.4f * h) + dx * drift + rise
        val base = (22f + 40f * ease) * d * spot.scale * (0.85f + 0.3f * h)
        // Soft in, long slow fade out.
        val env = if (age < 0.25f) age / 0.25f else (1f - age) / 0.75f
        val a = (0.15f * env * intensity).coerceIn(0f, 1f)
        // A few overlapping round lumps make the outline rough instead of a perfect circle.
        for (k in 0 until Lumps) {
            val hk = hash(seed * 131 + i * 13 + k)
            val ang = (k / Lumps.toFloat()) * 2f * PI.toFloat() + hk * 2f + age * (0.6f + hk)
            val off = base * (0.25f + 0.35f * hash(seed * 71 + i * 5 + k))
            val lx = cx + cos(ang) * off
            val ly = cy + sin(ang) * off
            val lr = base * (0.55f + 0.35f * hk)
            drawCircle(
                brush = Brush.radialGradient(
                    0f to color.copy(alpha = a * 0.7f),
                    0.65f to color.copy(alpha = a * 0.55f),
                    1f to Color.Transparent,
                    center = Offset(lx, ly), radius = lr,
                ),
                radius = lr, center = Offset(lx, ly),
            )
        }
    }
}

/**
 * Placement mode. One handle per spot: drag to move, pinch to resize, twist with two fingers to rotate.
 * Rotating also works with one finger by dragging the small knob on the arrow.
 */
@Composable
fun BreathEditor(
    settings: LauncherSettings,
    initial: List<BreathSpot>,
    onDone: (List<BreathSpot>) -> Unit,
) {
    val spots = remember { mutableStateListOf<BreathSpot>().also { it.addAll(initial) } }
    var selected by remember { mutableStateOf(if (initial.isEmpty()) -1 else 0) }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.25f))
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        val wPx = constraints.maxWidth.toFloat()
        val hPx = constraints.maxHeight.toFloat()

        ColdBreath(settings.copy(breathEnabled = true), spots.toList())

        spots.forEachIndexed { i, spot ->
            val handle = 72.dp
            val handlePx = with(androidx.compose.ui.platform.LocalDensity.current) { handle.toPx() }
            val isSel = i == selected
            Box(
                Modifier
                    .offset { IntOffset((spot.x * wPx - handlePx / 2).roundToInt(), (spot.y * hPx - handlePx / 2).roundToInt()) }
                    .size(handle)
                    .graphicsLayer { rotationZ = spot.angle; scaleX = spot.scale.coerceIn(0.7f, 1.6f); scaleY = spot.scale.coerceIn(0.7f, 1.6f) }
                    .border(2.dp, if (isSel) Color.White else Color.White.copy(alpha = 0.5f), CircleShape)
                    .background(Color.White.copy(alpha = if (isSel) 0.22f else 0.1f), CircleShape)
                    .pointerInput(i, wPx, hPx) {
                        detectTransformGestures { _, pan, zoom, rotation ->
                            val cur = spots.getOrNull(i) ?: return@detectTransformGestures
                            selected = i
                            // pan arrives in the rotated, scaled local space; rotate it back to screen space.
                            val r = cur.angle * (PI.toFloat() / 180f)
                            val s = cur.scale.coerceIn(0.7f, 1.6f)
                            val px = (pan.x * cos(r) - pan.y * sin(r)) * s
                            val py = (pan.x * sin(r) + pan.y * cos(r)) * s
                            spots[i] = cur.copy(
                                x = (cur.x + px / wPx).coerceIn(0f, 1f),
                                y = (cur.y + py / hPx).coerceIn(0f, 1f),
                                angle = cur.angle + rotation,
                                scale = (cur.scale * zoom).coerceIn(0.4f, 3f),
                            )
                        }
                    },
                contentAlignment = Alignment.CenterEnd,
            ) {
                // Arrow tip shows where the breath goes.
                Box(Modifier.size(14.dp).background(Color.White, CircleShape))
            }
            if (isSel) {
                // Rotate knob, placed out along the angle.
                val r = spot.angle * (PI.toFloat() / 180f)
                val knobPx = handlePx * 0.5f * spot.scale.coerceIn(0.7f, 1.6f) + 52f
                val kx = spot.x * wPx + cos(r) * knobPx
                val ky = spot.y * hPx + sin(r) * knobPx
                val knob = 36.dp
                val knobHalf = with(androidx.compose.ui.platform.LocalDensity.current) { knob.toPx() / 2 }
                Box(
                    Modifier
                        .offset { IntOffset((kx - knobHalf).roundToInt(), (ky - knobHalf).roundToInt()) }
                        .size(knob)
                        .background(MaterialTheme.colorScheme.primary, CircleShape)
                        .pointerInput(i, wPx, hPx) {
                            var pos = Offset.Zero
                            detectDragGestures(
                                onDragStart = {
                                    val c = spots.getOrNull(i)
                                    if (c != null) {
                                        val rr = c.angle * (PI.toFloat() / 180f)
                                        val kp = handlePx * 0.5f * c.scale.coerceIn(0.7f, 1.6f) + 52f
                                        pos = Offset(c.x * wPx + cos(rr) * kp, c.y * hPx + sin(rr) * kp)
                                    }
                                },
                            ) { change, amount ->
                                change.consume()
                                pos += amount
                                val cur = spots.getOrNull(i) ?: return@detectDragGestures
                                val ang = Math.toDegrees(
                                    kotlin.math.atan2((pos.y - cur.y * hPx).toDouble(), (pos.x - cur.x * wPx).toDouble())
                                ).toFloat()
                                spots[i] = cur.copy(angle = ang)
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) { Text("↻", color = Color.White) }
            }
        }

        // Bottom bar
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(16.dp)
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f), RoundedCornerShape(28.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            EditorButton("Add") {
                if (spots.size < BreathMaxSpots) {
                    spots.add(BreathSpot(0.5f, 0.5f, -20f, 1f)); selected = spots.lastIndex
                }
            }
            EditorButton("Delete", enabled = selected in spots.indices) {
                spots.removeAt(selected); selected = spots.lastIndex
            }
            EditorButton("Done", primary = true) { onDone(spots.toList()) }
        }
        Text(
            "Drag to move · pinch to resize · twist or use ↻ to turn",
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 12.dp)
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun EditorButton(label: String, enabled: Boolean = true, primary: Boolean = false, onClick: () -> Unit) {
    Text(
        label,
        Modifier
            .clickable(enabled = enabled, onClick = onClick)
            .background(if (primary) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(20.dp))
            .padding(horizontal = 18.dp, vertical = 10.dp),
        style = MaterialTheme.typography.labelLarge,
        color = when {
            primary -> MaterialTheme.colorScheme.onPrimary
            enabled -> MaterialTheme.colorScheme.onSurface
            else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
        },
    )
}
