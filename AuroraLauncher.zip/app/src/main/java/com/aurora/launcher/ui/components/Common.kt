package com.aurora.launcher.ui.components

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurora.launcher.data.IconShape
import com.aurora.launcher.data.IconTheme
import com.aurora.launcher.ui.theme.LocalAurora
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

fun shapeFor(shape: IconShape): Shape = when (shape) {
    IconShape.CIRCLE -> CircleShape
    IconShape.SQUIRCLE -> RoundedCornerShape(32)
    IconShape.ROUNDED -> RoundedCornerShape(22)
    IconShape.SQUARE -> RoundedCornerShape(10)
    IconShape.TEARDROP -> RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 50, bottomStartPercent = 12)
}

/**
 * Frosted surface used for the dock, search bar, folders and panels.
 * With [aurora] = true the surface also gets the animated aurora glow and gradient rim (when enabled in settings).
 */
@Composable
fun Modifier.glass(shape: Shape, strong: Boolean = false, aurora: Boolean = false): Modifier {
    val a = LocalAurora.current
    val glowMod = if (aurora && a.glowOn) {
        Modifier.drawBehind {
            val c = a.glowColor()
            val base = (size.minDimension / 2f).coerceAtMost(28.dp.toPx())
            for (i in 1..5) {
                val grow = i * 2.5.dp.toPx()
                drawRoundRect(
                    color = c.copy(alpha = 0.16f - i * 0.025f),
                    topLeft = Offset(-grow, -grow),
                    size = Size(size.width + 2 * grow, size.height + 2 * grow),
                    cornerRadius = CornerRadius(base + grow),
                )
            }
        }
    } else Modifier
    val rim = if (aurora && a.accentOn) {
        Modifier.border(1.2.dp, Brush.linearGradient(a.gradient), shape)
    } else {
        Modifier.border(0.6.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f), shape)
    }
    return this
        .then(glowMod)
        .clip(shape)
        .background(if (strong) a.glassStrong else a.glass, shape)
        .then(rim)
}

/** Grayscale or accent-tinted icon themes, applied as a color matrix (no re-rendering needed). */
@Composable
fun rememberIconFilter(theme: IconTheme): ColorFilter? {
    val primary = MaterialTheme.colorScheme.primary
    return when (theme) {
        IconTheme.ORIGINAL -> null
        IconTheme.GRAYSCALE -> ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
        IconTheme.TINTED -> {
            // out = luminance * accent, so every icon becomes a shade of the accent color.
            val lr = 0.213f; val lg = 0.715f; val lb = 0.072f
            val r = primary.red * 1.15f; val g = primary.green * 1.15f; val b = primary.blue * 1.15f
            ColorFilter.colorMatrix(
                ColorMatrix(
                    floatArrayOf(
                        lr * r, lg * r, lb * r, 0f, 0f,
                        lr * g, lg * g, lb * g, 0f, 0f,
                        lr * b, lg * b, lb * b, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f,
                    )
                )
            )
        }
    }
}

/** Large clock + date, ticking once per minute. */
@Composable
fun ClockWidget(
    modifier: Modifier = Modifier,
    scale: Float = 1f,
    align: Alignment.Horizontal = Alignment.Start,
) {
    val context = LocalContext.current
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L))
        }
    }
    val pattern = if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm"
    val locale = Locale.getDefault()
    val color = LocalAurora.current.onWallpaper
    val aurora = LocalAurora.current
    val timeStyle = MaterialTheme.typography.displayMedium.let {
        val sized = it.copy(fontSize = it.fontSize * scale)
        if (aurora.clockOn) sized.copy(brush = Brush.linearGradient(aurora.gradient)) else sized
    }
    val dateStyle = MaterialTheme.typography.titleMedium.let { it.copy(fontSize = it.fontSize * scale) }
    Column(modifier, horizontalAlignment = align) {
        Text(
            now.format(DateTimeFormatter.ofPattern(pattern, locale)),
            style = timeStyle,
            color = if (aurora.clockOn) Color.Unspecified else color,
        )
        Text(
            now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", locale)),
            style = dateStyle,
            color = color.copy(alpha = 0.85f),
        )
        if (aurora.clockOn) {
            // Thin light streak under the date
            Box(
                Modifier
                    .padding(top = 6.dp)
                    .width((96f * scale).dp)
                    .height(2.dp)
                    .background(Brush.horizontalGradient(aurora.gradient), RoundedCornerShape(2.dp))
            )
        }
    }
}
