package com.aurora.launcher.ui.components

import android.content.Context
import android.content.pm.ShortcutInfo
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import kotlin.math.absoluteValue
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.launcher.LauncherApp
import com.aurora.launcher.data.AppInfo
import com.aurora.launcher.data.AppRepository
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.ui.theme.LocalAurora
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** One entry of an icon's long-press menu. */
data class MenuAction(val label: String, val icon: ImageVector, val onClick: () -> Unit)

fun Context.appRepository(): AppRepository = (applicationContext as LauncherApp).apps

/** Loads the icon bitmap off the main thread; null until ready. */
@Composable
fun rememberAppIcon(app: AppInfo): ImageBitmap? {
    val repo = LocalContext.current.appRepository()
    return produceState<ImageBitmap?>(null, app.key) { value = repo.icon(app) }.value
}

/** The icon artwork alone: shaped, themed, no label or gestures. */
@Composable
fun IconArt(app: AppInfo, settings: LauncherSettings, size: Dp, modifier: Modifier = Modifier) {
    val bitmap = rememberAppIcon(app)
    val shape = shapeFor(settings.iconShape)
    val filter = rememberIconFilter(settings.iconTheme)
    val aurora = LocalAurora.current

    // One light sweep when the icon appears (staggered per app). Zero cost while idle.
    val sweep = remember(app.key) { Animatable(1f) }
    if (settings.iconShimmer) {
        LaunchedEffect(app.key) {
            sweep.snapTo(0f)
            delay((app.key.hashCode().absoluteValue % 8) * 70L + 250L)
            sweep.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        }
    }

    Box(
        modifier
            .size(size)
            .then(
                if (aurora.glowOn) Modifier.drawBehind {
                    val c = aurora.glowColor()
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(c.copy(alpha = 0.30f), Color.Transparent),
                            center = center, radius = this.size.minDimension * 0.78f,
                        ),
                        radius = this.size.minDimension * 0.78f,
                    )
                } else Modifier
            )
            .clip(shape)
            .then(
                if (settings.iconShimmer) Modifier.drawWithContent {
                    drawContent()
                    val p = sweep.value
                    if (p < 1f) {
                        val w = this.size.width
                        val x = -w * 0.6f + p * w * 2.2f
                        drawRect(
                            brush = Brush.linearGradient(
                                listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
                                start = Offset(x, 0f),
                                end = Offset(x + w * 0.5f, this.size.height * 0.5f),
                            )
                        )
                    }
                } else Modifier
            )
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = app.label,
                contentScale = ContentScale.Crop,
                colorFilter = filter,
                modifier = Modifier.size(size),
            )
        }
    }
}

/**
 * An app icon with label, tap-to-launch, long-press menu (real app shortcuts + actions)
 * and optional drag support.
 */
@Composable
fun AppIconView(
    app: AppInfo,
    settings: LauncherSettings,
    drag: DragState,
    payload: DragPayload,
    actions: List<MenuAction>,
    onLaunch: (Rect) -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = settings.iconSizeDp.dp,
    showLabel: Boolean = settings.showLabels,
    labelColor: Color = LocalAurora.current.onWallpaper,
    dimmed: Boolean = false,
    labelOverride: String? = null,
) {
    var menuOpen by remember { mutableStateOf(false) }
    val repo = LocalContext.current.appRepository()

    Column(
        modifier = modifier
            .alpha(if (dimmed) 0.25f else 1f)
            .dragSource(
                onTap = onLaunch,
                onMenu = { menuOpen = true },
                onDragStart = { drag.start(payload, it) },
                onDrag = drag::move,
                onDragEnd = drag::end,
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box {
            IconArt(app, settings, iconSize)
            AppMenu(app, menuOpen, { menuOpen = false }, actions, repo)
        }
        if (showLabel) {
            Text(
                text = labelOverride ?: app.label,
                color = labelColor,
                fontSize = settings.labelSizeSp.sp,
                fontWeight = if (settings.labelBold) FontWeight.SemiBold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelMedium.copy(
                    shadow = Shadow(Color.Black.copy(alpha = 0.45f), blurRadius = 6f)
                ),
                modifier = Modifier.padding(top = 4.dp).widthIn(max = iconSize + 20.dp),
            )
        }
    }
}

/** Long-press menu: the app's own shortcuts first, then launcher actions. */
@Composable
fun AppMenu(
    app: AppInfo,
    expanded: Boolean,
    onDismiss: () -> Unit,
    actions: List<MenuAction>,
    repo: AppRepository,
) {
    val shortcuts by produceState(emptyList<ShortcutInfo>(), expanded, app.key) {
        value = if (expanded) withContext(Dispatchers.IO) { repo.shortcuts(app) } else emptyList()
    }
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(20.dp),
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Text(
            app.label,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).widthIn(min = 160.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        shortcuts.forEach { sc ->
            val icon by produceState<ImageBitmap?>(null, sc.id) { value = repo.shortcutIcon(sc) }
            DropdownMenuItem(
                text = { Text(sc.shortLabel?.toString().orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                leadingIcon = {
                    icon?.let { Image(it, null, Modifier.size(24.dp).clip(RoundedCornerShape(6.dp))) }
                        ?: Box(Modifier.size(24.dp))
                },
                onClick = { repo.startShortcut(sc); onDismiss() },
            )
        }
        if (shortcuts.isNotEmpty()) HorizontalDivider(Modifier.padding(vertical = 4.dp))
        actions.forEach { a ->
            DropdownMenuItem(
                text = { Text(a.label) },
                leadingIcon = { Icon(a.icon, null, Modifier.size(20.dp)) },
                onClick = { onDismiss(); a.onClick() },
            )
        }
    }
}
