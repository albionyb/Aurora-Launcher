package com.aurora.launcher.ui

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.os.Bundle
import android.provider.MediaStore
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.launcher.LauncherApp
import com.aurora.launcher.data.AppInfo
import com.aurora.launcher.data.Container
import com.aurora.launcher.data.DrawerSort
import com.aurora.launcher.data.HomeItem
import com.aurora.launcher.data.ItemType
import com.aurora.launcher.data.Keys
import com.aurora.launcher.data.LauncherSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Where a dragged item is being dropped. */
sealed interface DropTarget {
    data class HomeCell(val page: Int, val x: Int, val y: Int) : DropTarget
    data class DockSlot(val slot: Int) : DropTarget
}

private data class Cell(val page: Int, val x: Int, val y: Int)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as LauncherApp
    private val appRepo = app.apps
    private val settingsRepo = app.settings
    private val homeDao = app.database.homeDao()
    private val usageDao = app.database.usageDao()
    private val pm: PackageManager = application.packageManager

    val settings: StateFlow<LauncherSettings> = settingsRepo.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, LauncherSettings())

    /** Every launchable app, hidden ones included (needed to resolve home items and search). */
    val allApps: StateFlow<List<AppInfo>> = appRepo.apps
    val appsLoaded: StateFlow<Boolean> = appRepo.loaded

    val appsByKey: StateFlow<Map<String, AppInfo>> = appRepo.apps
        .map { list -> list.associateBy { it.key } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    private val usage = usageDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Apps shown in the drawer: hidden apps removed, sorted per the user's choice. */
    val drawerApps: StateFlow<List<AppInfo>> = combine(
        appRepo.apps, settingsRepo.settings.map { it.hiddenApps to it.drawerSort }.distinctUntilChanged(), usage
    ) { apps, (hidden, sort), usageList ->
        val visible = apps.filter { it.key !in hidden }
        val launches = usageList.associate { it.appKey to it.launches }
        when (sort) {
            DrawerSort.AZ -> visible
            DrawerSort.ZA -> visible.reversed()
            DrawerSort.NEWEST -> visible.sortedByDescending { it.installTime }
            DrawerSort.MOST_USED -> visible.sortedWith(
                compareByDescending<AppInfo> { launches[it.key] ?: 0 }.thenBy { it.label.lowercase() }
            )
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val frequentApps: StateFlow<List<AppInfo>> = combine(drawerApps, usage) { apps, usageList ->
        val byKey = apps.associateBy { it.key }
        usageList.sortedByDescending { it.launches }.mapNotNull { byKey[it.appKey] }.take(5)
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recentApps: StateFlow<List<AppInfo>> = drawerApps
        .map { apps ->
            val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
            apps.filter { it.installTime > weekAgo }.sortedByDescending { it.installTime }.take(5)
        }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val homeItems: StateFlow<List<HomeItem>> = homeDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Emitted when the Home button is pressed while we are already on top. */
    private val _homePressed = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val homePressed: SharedFlow<Unit> = _homePressed
    fun onHomePressed() { _homePressed.tryEmit(Unit) }

    init {
        viewModelScope.launch { seedDefaultsOnce() }
        viewModelScope.launch {
            // When the grid or dock shrinks, push now-out-of-range items onto free cells.
            settingsRepo.settings
                .map { Triple(it.gridColumns, it.gridRows, it.dockCount) }
                .distinctUntilChanged()
                .collect { reflow(it.first, it.second, it.third) }
        }
        viewModelScope.launch {
            // Remove home items whose package really is gone (not just a locked work profile).
            appRepo.loaded.first { it }
            pruneUninstalled()
        }
    }

    // ---------- Settings ----------

    fun <T> set(key: Preferences.Key<T>, value: T) {
        viewModelScope.launch { settingsRepo.set(key, value) }
    }

    fun setHidden(app: AppInfo, hidden: Boolean) {
        viewModelScope.launch { settingsRepo.setHidden(app.key, hidden) }
    }

    fun addRecentSearch(q: String) { viewModelScope.launch { settingsRepo.addRecentSearch(q) } }
    fun clearRecentSearches() { viewModelScope.launch { settingsRepo.clearRecentSearches() } }

    // ---------- Launching ----------

    fun launch(app: AppInfo, bounds: Rect?, options: Bundle?) {
        appRepo.launch(app, bounds, options)
        viewModelScope.launch { usageDao.record(app.key, System.currentTimeMillis()) }
    }

    // ---------- Home layout ----------

    /** First launch: dock gets the system's real default dialer/messages/browser/camera. */
    private suspend fun seedDefaultsOnce() {
        val s = settingsRepo.settings.first()
        if (s.setupDone) return
        appRepo.loaded.first { it }
        if (homeDao.count() == 0) {
            val intents = listOf(
                Intent(Intent.ACTION_DIAL),
                Intent(Intent.ACTION_VIEW, android.net.Uri.parse("sms:")),
                Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://example.com")),
                Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            )
            val apps = appRepo.apps.value
            val picked = LinkedHashMap<String, AppInfo>()
            for (intent in intents) {
                val pkg = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName ?: continue
                apps.firstOrNull { it.packageName == pkg }?.let { picked.putIfAbsent(it.key, it) }
            }
            picked.values.take(s.dockCount).forEachIndexed { i, a ->
                homeDao.insert(HomeItem(type = ItemType.APP, container = Container.DOCK, cellX = i, appKey = a.key))
            }
        }
        settingsRepo.set(Keys.INTRO_SEEN, false)
        settingsRepo.set(Keys.SETUP_DONE, true)
    }

    private suspend fun pruneUninstalled() {
        for (item in homeDao.getAll()) {
            val key = item.appKey ?: continue
            val pkg = key.substringBefore('/')
            val installed = try {
                pm.getPackageInfo(pkg, 0); true
            } catch (e: PackageManager.NameNotFoundException) {
                // Could still live in another profile; only prune when no profile lists it.
                appRepo.apps.value.any { it.packageName == pkg }
            }
            if (!installed) homeDao.deleteById(item.id)
        }
        normalizeFolders()
    }

    private fun findFreeCell(items: List<HomeItem>, cols: Int, rows: Int, ignoreId: Long = -1): Cell {
        val occupied = items.filter { it.container == Container.HOME && it.id != ignoreId }
            .map { Cell(it.page, it.cellX, it.cellY) }.toSet()
        var page = 0
        while (true) {
            for (y in 0 until rows) for (x in 0 until cols) {
                if (Cell(page, x, y) !in occupied) return Cell(page, x, y)
            }
            page++
        }
    }

    private suspend fun reflow(cols: Int, rows: Int, dockCount: Int) {
        var items = homeDao.getAll()
        for (item in items) {
            val outOfRange = when (item.container) {
                Container.HOME -> item.cellX >= cols || item.cellY >= rows
                Container.DOCK -> item.cellX >= dockCount
                else -> false
            }
            if (outOfRange) {
                val cell = findFreeCell(items, cols, rows, item.id)
                homeDao.update(item.copy(container = Container.HOME, page = cell.page, cellX = cell.x, cellY = cell.y))
                items = homeDao.getAll()
            }
        }
    }

    fun addToHome(app: AppInfo) {
        viewModelScope.launch {
            val s = settings.value
            val cell = findFreeCell(homeDao.getAll(), s.gridColumns, s.gridRows)
            homeDao.insert(
                HomeItem(type = ItemType.APP, container = Container.HOME, page = cell.page,
                    cellX = cell.x, cellY = cell.y, appKey = app.key)
            )
        }
    }

    /** Drop a new app (from the drawer) onto a cell or dock slot. */
    fun dropApp(app: AppInfo, target: DropTarget) {
        viewModelScope.launch {
            place(HomeItem(type = ItemType.APP, container = Container.HOME, appKey = app.key), target)
            normalizeFolders()
        }
    }

    /** Drop an existing item (moved within home / out of a folder). */
    fun dropItem(itemId: Long, target: DropTarget) {
        viewModelScope.launch {
            val item = homeDao.getAll().firstOrNull { it.id == itemId } ?: return@launch
            place(item, target)
            normalizeFolders()
        }
    }

    private suspend fun place(item: HomeItem, target: DropTarget) {
        val items = homeDao.getAll()
        val (container, page, x, y) = when (target) {
            is DropTarget.HomeCell -> listOf<Any>(Container.HOME, target.page, target.x, target.y)
            is DropTarget.DockSlot -> listOf<Any>(Container.DOCK, 0, target.slot, 0)
        }
        val c = container as String
        val p = page as Int
        val cx = x as Int
        val cy = y as Int
        val occupant = items.firstOrNull {
            it.id != item.id && it.container == c && it.cellX == cx &&
                (c == Container.DOCK || (it.page == p && it.cellY == cy))
        }
        suspend fun save(i: HomeItem) { if (i.id == 0L) homeDao.insert(i) else homeDao.update(i) }

        when {
            occupant == null ->
                save(item.copy(container = c, parentId = 0, page = p, cellX = cx, cellY = cy))
            item.type == ItemType.APP && occupant.type == ItemType.FOLDER -> {
                val n = items.count { it.container == Container.FOLDER && it.parentId == occupant.id }
                save(item.copy(container = Container.FOLDER, parentId = occupant.id, page = 0, cellX = n, cellY = 0))
            }
            item.type == ItemType.APP && occupant.type == ItemType.APP -> {
                // Dropping an app on an app makes a folder at that spot.
                val folderId = homeDao.insert(
                    HomeItem(type = ItemType.FOLDER, container = c, page = p, cellX = cx, cellY = cy, title = "Folder")
                )
                homeDao.update(occupant.copy(container = Container.FOLDER, parentId = folderId, page = 0, cellX = 0, cellY = 0))
                save(item.copy(container = Container.FOLDER, parentId = folderId, page = 0, cellX = 1, cellY = 0))
            }
            else -> {
                // Folder onto something: swap places (only possible if the dragged item has a slot).
                if (item.id != 0L && item.container != Container.FOLDER) {
                    homeDao.update(occupant.copy(container = item.container, page = item.page, cellX = item.cellX, cellY = item.cellY))
                    save(item.copy(container = c, page = p, cellX = cx, cellY = cy))
                }
            }
        }
    }

    /** Folders with 0 members vanish; folders with 1 member give that app back its slot. */
    private suspend fun normalizeFolders() {
        val items = homeDao.getAll()
        for (folder in items.filter { it.type == ItemType.FOLDER }) {
            val members = items.filter { it.container == Container.FOLDER && it.parentId == folder.id }
            when (members.size) {
                0 -> homeDao.deleteById(folder.id)
                1 -> {
                    homeDao.update(members[0].copy(container = folder.container, parentId = 0,
                        page = folder.page, cellX = folder.cellX, cellY = folder.cellY))
                    homeDao.deleteById(folder.id)
                }
            }
        }
    }

    fun removeItem(itemId: Long) {
        viewModelScope.launch {
            homeDao.deleteWithChildren(itemId)
            normalizeFolders()
        }
    }

    fun removeFromFolder(item: HomeItem) {
        viewModelScope.launch {
            val s = settings.value
            val cell = findFreeCell(homeDao.getAll(), s.gridColumns, s.gridRows)
            homeDao.update(item.copy(container = Container.HOME, parentId = 0, page = cell.page, cellX = cell.x, cellY = cell.y))
            normalizeFolders()
        }
    }

    fun renameFolder(folder: HomeItem, title: String) {
        viewModelScope.launch { homeDao.update(folder.copy(title = title.trim().ifEmpty { "Folder" })) }
    }

    fun resetLayout() {
        viewModelScope.launch {
            homeDao.clear()
            settingsRepo.set(Keys.SETUP_DONE, false)
            seedDefaultsOnce()
        }
    }

    // Backup support (see Backup.kt)
    suspend fun allHomeItems(): List<HomeItem> = homeDao.getAll()
    suspend fun replaceHomeItems(items: List<HomeItem>) {
        homeDao.clear()
        homeDao.insertAll(items)
    }
    val settingsRepository get() = settingsRepo
}
