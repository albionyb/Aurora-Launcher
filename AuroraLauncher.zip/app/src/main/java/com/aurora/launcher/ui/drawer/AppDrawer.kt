package com.aurora.launcher.ui.drawer

import android.view.View
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.animation.core.animateDecay
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.launcher.data.AppCategory
import com.aurora.launcher.data.AppInfo
import com.aurora.launcher.data.DrawerSort
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.ui.LauncherViewModel
import com.aurora.launcher.ui.components.AppIconView
import com.aurora.launcher.ui.components.DragPayload
import com.aurora.launcher.ui.components.DragState
import com.aurora.launcher.ui.components.MenuAction
import com.aurora.launcher.ui.components.appRepository
import com.aurora.launcher.ui.components.glass
import com.aurora.launcher.ui.home.launchOptions
import com.aurora.launcher.ui.home.toAndroid
import kotlinx.coroutines.launch

private sealed interface Entry {
    val key: String
    data class Header(val title: String) : Entry { override val key = "h_$title" }
    data class AppItem(val app: AppInfo) : Entry { override val key = "a_${app.key}" }
    data class Strip(val id: String, val title: String, val apps: List<AppInfo>) : Entry { override val key = "s_$id" }
}

private fun letterOf(label: String): String {
    val c = label.firstOrNull()?.uppercaseChar() ?: '#'
    return if (c.isLetter()) c.toString() else "#"
}

@Composable
fun AppDrawer(
    vm: LauncherViewModel,
    settings: LauncherSettings,
    drag: DragState,
    onOpenSearch: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val apps by vm.drawerApps.collectAsStateWithLifecycle()
    val frequent by vm.frequentApps.collectAsStateWithLifecycle()
    val recent by vm.recentApps.collectAsStateWithLifecycle()
    val loaded by vm.appsLoaded.collectAsStateWithLifecycle()
    val repo = LocalContext.current.appRepository()
    val view: View = LocalView.current
    val scope = rememberCoroutineScope()
    val gridState = rememberLazyGridState()

    val alphabetical = settings.drawerSort == DrawerSort.AZ || settings.drawerSort == DrawerSort.ZA

    val entries: List<Entry> = remember(apps, frequent, recent, settings.drawerCategories, settings.drawerSort, settings.drawerSuggestions) {
        buildList {
            if (settings.drawerSuggestions && !settings.drawerCategories) {
                if (frequent.isNotEmpty()) add(Entry.Strip("freq", "Frequently used", frequent))
                if (recent.isNotEmpty()) add(Entry.Strip("recent", "Recently installed", recent))
            }
            if (settings.drawerCategories) {
                apps.groupBy { it.category }.toSortedMap(compareBy<AppCategory> { it.ordinal }).forEach { (cat, list) ->
                    add(Entry.Header(cat.label))
                    list.sortedBy { it.label.lowercase() }.forEach { add(Entry.AppItem(it)) }
                }
            } else if (alphabetical) {
                var last = ""
                apps.forEach {
                    val l = letterOf(it.label)
                    if (l != last) { add(Entry.Header(l)); last = l }
                    add(Entry.AppItem(it))
                }
            } else {
                apps.forEach { add(Entry.AppItem(it)) }
            }
        }
    }

    // Swipe down while already at the top closes the drawer.
    val closeNow by androidx.compose.runtime.rememberUpdatedState(onClose)
    val closeConnection = remember(gridState) {
        object : NestedScrollConnection {
            var pulled = 0f
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source == NestedScrollSource.UserInput && available.y > 0f && gridState.firstVisibleItemIndex == 0 &&
                    gridState.firstVisibleItemScrollOffset == 0
                ) {
                    pulled += available.y
                    if (pulled > 260f) { pulled = 0f; closeNow() }
                } else if (consumed.y != 0f) pulled = 0f
                return Offset.Zero
            }
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity { pulled = 0f; return Velocity.Zero }
        }
    }

    val smoothFling = rememberSmoothFling()

    Box(
        modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background.copy(alpha = (settings.glassAlpha + 0.25f).coerceAtMost(0.95f)))
            .statusBarsPadding()
    ) {
        Column(Modifier.fillMaxSize()) {
            // Search entry point
            Row(
                Modifier
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(28.dp), strong = true)
                    .clickable(onClick = onOpenSearch)
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Outlined.Search, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("  Search ${apps.size} apps", color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyLarge)
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (loaded && apps.isEmpty()) {
                    Text("No apps found", Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(settings.drawerColumns),
                    state = gridState,
                    contentPadding = PaddingValues(start = 12.dp, end = if (alphabetical && !settings.drawerCategories) 32.dp else 12.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    flingBehavior = smoothFling,
                    modifier = Modifier.fillMaxSize().nestedScroll(closeConnection).navigationBarsPadding(),
                ) {
                    items(
                        entries,
                        key = { it.key },
                        span = { e -> if (e is Entry.AppItem) GridItemSpan(1) else GridItemSpan(maxLineSpan) },
                    ) { e ->
                        when (e) {
                            is Entry.Header -> Text(
                                e.title,
                                Modifier.padding(start = 12.dp, top = 10.dp),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            is Entry.AppItem -> DrawerIcon(e.app, settings, drag, vm, repo, view)
                            is Entry.Strip -> Column {
                                Text(e.title, Modifier.padding(start = 12.dp, bottom = 8.dp),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(Modifier.fillMaxWidth()) {
                                    e.apps.forEach { a ->
                                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                            DrawerIcon(a, settings, drag, vm, repo, view)
                                        }
                                    }
                                    repeat((5 - e.apps.size).coerceAtLeast(0)) { Box(Modifier.weight(1f)) }
                                }
                            }
                        }
                    }
                }

                if (alphabetical && !settings.drawerCategories && entries.isNotEmpty()) {
                    val headers = remember(entries) {
                        entries.mapIndexedNotNull { i, e -> (e as? Entry.Header)?.let { it.title to i } }
                    }
                    if (headers.size > 1) LetterIndex(
                        letters = headers.map { it.first },
                        modifier = Modifier.align(Alignment.CenterEnd),
                        onSelect = { idx -> scope.launch { gridState.scrollToItem(headers[idx].second) } },
                    )
                }
            }
        }
    }
}

@Composable
private fun DrawerIcon(
    app: AppInfo,
    settings: LauncherSettings,
    drag: DragState,
    vm: LauncherViewModel,
    repo: com.aurora.launcher.data.AppRepository,
    view: View,
) {
    AppIconView(
        app = app,
        settings = settings,
        drag = drag,
        payload = DragPayload.FromDrawer(app),
        labelColor = MaterialTheme.colorScheme.onBackground,
        actions = listOf(
            MenuAction("Add to home", Icons.Outlined.Add) { vm.addToHome(app) },
            MenuAction("App info", Icons.Outlined.Info) { repo.openAppInfo(app) },
            MenuAction("Hide app", Icons.Outlined.VisibilityOff) { vm.setHidden(app, true) },
            MenuAction("Uninstall", Icons.Outlined.Delete) { repo.uninstall(app) },
        ),
        onLaunch = { b -> vm.launch(app, b.toAndroid(), launchOptions(settings, repo, view, b)) },
    )
}

/** A–Z strip on the right edge; touch or drag along it to jump. */
@Composable
private fun LetterIndex(letters: List<String>, modifier: Modifier, onSelect: (Int) -> Unit) {
    Column(
        modifier
            .fillMaxHeight(0.8f)
            .width(28.dp)
            .pointerInput(letters) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    fun pick(y: Float) = onSelect((y / size.height * letters.size).toInt().coerceIn(0, letters.size - 1))
                    pick(down.position.y)
                    do {
                        val event = awaitPointerEvent()
                        event.changes.firstOrNull()?.let { pick(it.position.y); it.consume() }
                    } while (event.changes.any { it.pressed })
                }
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        letters.forEach {
            Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}


/**
 * A softer fling than the default: a lower friction so the list keeps gliding and slows down
 * gradually instead of stopping quickly. Stops cleanly at the ends.
 */
@Composable
private fun rememberSmoothFling(): androidx.compose.foundation.gestures.FlingBehavior {
    val decay = remember { androidx.compose.animation.core.exponentialDecay<Float>(frictionMultiplier = 0.55f) }
    return remember(decay) {
        object : androidx.compose.foundation.gestures.FlingBehavior {
            override suspend fun androidx.compose.foundation.gestures.ScrollScope.performFling(initialVelocity: Float): Float {
                if (kotlin.math.abs(initialVelocity) <= 1f) return initialVelocity
                var lastValue = 0f
                var remaining = initialVelocity
                androidx.compose.animation.core.AnimationState(0f, initialVelocity).animateDecay(decay) {
                    val delta = value - lastValue
                    val consumed = scrollBy(delta)
                    lastValue = value
                    remaining = velocity
                    // Hit the top or bottom: stop instead of animating into nothing.
                    if (kotlin.math.abs(delta - consumed) > 0.5f) cancelAnimation()
                }
                return remaining
            }
        }
    }
}
