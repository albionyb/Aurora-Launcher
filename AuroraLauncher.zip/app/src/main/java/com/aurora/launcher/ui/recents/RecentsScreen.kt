package com.aurora.launcher.ui.recents

import android.app.ActivityOptions
import android.content.Intent
import android.graphics.Rect
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.PictureInPictureAlt
import androidx.compose.material.icons.outlined.VerticalSplit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.launcher.AuroraAccessibilityService
import com.aurora.launcher.data.AppInfo
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.data.hasUsageAccess
import com.aurora.launcher.data.killApp
import com.aurora.launcher.data.recentPackages
import com.aurora.launcher.ui.LauncherViewModel
import com.aurora.launcher.ui.components.IconArt
import com.aurora.launcher.ui.components.appRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Aurora's own app switcher. Android draws the system Recents screen itself and a launcher cannot
 * add buttons to it, so this screen offers the actions that were missing there:
 * split screen, small (floating) window, app info and close app.
 */
@Composable
fun RecentsScreen(vm: LauncherViewModel, settings: LauncherSettings, onClose: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val allApps by vm.allApps.collectAsStateWithLifecycle()
    var access by remember { mutableStateOf(hasUsageAccess(context)) }
    var tick by remember { mutableIntStateOf(0) }
    var closed by remember { mutableStateOf(setOf<String>()) }
    var needAccessibility by remember { mutableStateOf(false) }

    // Re-check permissions when coming back from the system settings pages.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) { access = hasUsageAccess(context); tick++ }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val recents: List<AppInfo> = remember(access, tick, allApps, closed) {
        if (!access) emptyList() else {
            val byPkg = allApps.groupBy { it.packageName }
            recentPackages(context)
                .filter { it !in closed }
                .mapNotNull { byPkg[it]?.firstOrNull() }
                .take(15)
        }
    }

    BackHandler { onClose() }

    fun open(app: AppInfo, options: android.os.Bundle? = null) { vm.launch(app, null, options); onClose() }

    fun closeApp(app: AppInfo) {
        killApp(context, app.packageName)
        closed = closed + app.packageName
    }

    fun smallWindow(app: AppInfo) {
        val dm = context.resources.displayMetrics
        val r = Rect((dm.widthPixels * 0.10f).toInt(), (dm.heightPixels * 0.20f).toInt(),
            (dm.widthPixels * 0.90f).toInt(), (dm.heightPixels * 0.65f).toInt())
        val opts = ActivityOptions.makeBasic().setLaunchBounds(r).toBundle()
        open(app, opts)
    }

    fun split(app: AppInfo) {
        if (!AuroraAccessibilityService.isEnabled) { needAccessibility = true; return }
        open(app)
        scope.launch {
            delay(650) // let the app reach the foreground, then ask the system to dock it
            AuroraAccessibilityService.toggleSplitScreen()
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() },
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(vertical = 24.dp)) {
            Text(
                "Recent apps", Modifier.padding(horizontal = 28.dp), color = Color.White,
                style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold,
            )
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                when {
                    !access -> InfoCard(
                        "Allow usage access",
                        "Android only tells Aurora which apps you used recently if you allow Usage access. Aurora keeps this on your device.",
                        "Open settings",
                    ) {
                        try {
                            context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (_: Exception) {
                        }
                    }
                    recents.isEmpty() -> Text("No recent apps", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.titleMedium)
                    else -> LazyRow(
                        contentPadding = PaddingValues(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        items(recents, key = { it.key }) { app ->
                            RecentCard(
                                app, settings,
                                onOpen = { open(app) },
                                onSplit = { split(app) },
                                onWindow = { smallWindow(app) },
                                onInfo = { context.appRepository().openAppInfo(app) },
                                onKill = { closeApp(app) },
                            )
                        }
                    }
                }
            }
            if (access && recents.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    Surface(
                        shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.clickable { recents.forEach { closeApp(it) } },
                    ) {
                        Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.DeleteSweep, null, tint = MaterialTheme.colorScheme.onSurface)
                            Spacer(Modifier.width(8.dp))
                            Text("Close all", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }

    if (needAccessibility) {
        AlertDialog(
            onDismissRequest = { needAccessibility = false },
            title = { Text("Turn on split screen") },
            text = {
                Text("Android only lets an accessibility service start split screen. Enable \"Aurora\" under Accessibility. It does not read your screen.")
            },
            confirmButton = {
                TextButton(onClick = {
                    needAccessibility = false
                    try {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                    }
                }) { Text("Open settings") }
            },
            dismissButton = { TextButton(onClick = { needAccessibility = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun InfoCard(title: String, body: String, button: String, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.padding(24.dp)) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(8.dp))
            Text(body, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onClick) { Text(button) }
        }
    }
}

@Composable
private fun RecentCard(
    app: AppInfo, settings: LauncherSettings,
    onOpen: () -> Unit, onSplit: () -> Unit, onWindow: () -> Unit, onInfo: () -> Unit, onKill: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.width(240.dp)
            // Swallow taps so they don't fall through and close the screen.
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
    ) {
        Column(Modifier.padding(vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Column(
                Modifier.clickable { onOpen() }.padding(horizontal = 20.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                IconArt(app, settings, 72.dp)
                Spacer(Modifier.height(10.dp))
                Text(
                    app.label, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium,
                )
            }
            Spacer(Modifier.height(12.dp))
            ActionLine(Icons.Outlined.VerticalSplit, "Split screen", onSplit)
            ActionLine(Icons.Outlined.PictureInPictureAlt, "Small window", onWindow)
            ActionLine(Icons.Outlined.Info, "App info", onInfo)
            ActionLine(Icons.Outlined.Close, "Close app", onKill)
        }
    }
}

@Composable
private fun ActionLine(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(14.dp))
        Text(label, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodyLarge)
    }
}
