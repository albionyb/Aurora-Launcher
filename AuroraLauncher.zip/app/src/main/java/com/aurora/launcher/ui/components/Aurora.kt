package com.aurora.launcher.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.launcher.ui.theme.LocalAurora
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

/**
 * Slow, soft ribbons of light drifting behind the home screen.
 * Drawn with radial gradients (no blur needed), so it works on every Android version.
 */
@Composable
fun AuroraRibbons(modifier: Modifier = Modifier) {
    val aurora = LocalAurora.current
    val t = rememberInfiniteTransition(label = "ribbons")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(24_000, easing = LinearEasing), RepeatMode.Restart),
        label = "ribbonPhase",
    )
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val ribbons = listOf(
            Triple(0.18f, -14f, aurora.c1),
            Triple(0.42f, 10f, aurora.c3),
            Triple(0.66f, -6f, aurora.c2),
        )
        ribbons.forEachIndexed { i, (yFrac, angle, color) ->
            val wave = sin((phase + i * 0.33f) * 2f * PI.toFloat())
            val cx = w / 2f + wave * w * 0.10f
            val cy = h * yFrac + wave * h * 0.02f
            val radius = w * 0.75f
            translate(left = cx - w / 2f, top = cy - h / 2f) {
                rotate(degrees = angle + wave * 4f, pivot = Offset(w / 2f, h / 2f)) {
                    scale(scaleX = 1f, scaleY = 0.18f, pivot = Offset(w / 2f, h / 2f)) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(color.copy(alpha = 0.55f), Color.Transparent),
                                center = Offset(w / 2f, h / 2f), radius = radius,
                            ),
                            radius = radius,
                            center = Offset(w / 2f, h / 2f),
                        )
                    }
                }
            }
        }
    }
}

/** First-launch intro: night-sky tile, a ribbon draws across it, the name fades in, then it dissolves. */
@Composable
fun AuroraIntro(onFinished: () -> Unit) {
    val aurora = LocalAurora.current
    val tile = remember { Animatable(0f) }
    val ribbon = remember { Animatable(0f) }
    val label = remember { Animatable(0f) }
    val out = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        tile.animateTo(1f, tween(600, easing = FastOutSlowInEasing))
        ribbon.animateTo(1f, tween(1300, easing = FastOutSlowInEasing))
        label.animateTo(1f, tween(600))
        delay(450)
        out.animateTo(0f, tween(500))
        onFinished()
    }
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = out.value }
            .background(Color(0xFF0B1220))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(
                Modifier
                    .size(132.dp)
                    .graphicsLayer {
                        val s = 0.7f + 0.3f * tile.value
                        scaleX = s; scaleY = s; alpha = tile.value
                    }
            ) {
                val k = size.width / 84f
                drawRoundRect(Color(0xFF121C30), cornerRadius = CornerRadius(20f * k))
                drawRoundRect(Color(0xFF1D2A44), cornerRadius = CornerRadius(20f * k), style = Stroke(width = 1.5f * k))
                val path = Path().apply {
                    moveTo(8f * k, 58f * k)
                    cubicTo(26f * k, 32f * k, 42f * k, 66f * k, 58f * k, 42f * k)
                    cubicTo(74f * k, 18f * k, 72f * k, 30f * k, 78f * k, 32f * k)
                }
                val measure = PathMeasure().apply { setPath(path, false) }
                val seg = Path()
                measure.getSegment(0f, measure.length * ribbon.value, seg, true)
                drawPath(
                    seg,
                    brush = Brush.horizontalGradient(aurora.gradient, startX = 8f * k, endX = 78f * k),
                    style = Stroke(width = 7f * k, cap = StrokeCap.Round),
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "AURORA",
                color = Color(0xFFE8FFF4).copy(alpha = label.value),
                fontSize = 20.sp,
                letterSpacing = 6.sp,
            )
        }
    }
}
