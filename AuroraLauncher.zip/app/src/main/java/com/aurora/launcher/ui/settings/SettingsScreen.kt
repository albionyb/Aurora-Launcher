package com.aurora.launcher.ui.settings

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import com.aurora.launcher.ui.search.selectedQuickSettings
import com.aurora.launcher.ui.search.quickSettings
import com.aurora.launcher.ui.search.QuickSetting
import com.aurora.launcher.data.HAlign
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Gesture
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.Widgets
import com.aurora.launcher.data.QuickMaxApps
import com.aurora.launcher.data.QuickStyle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aurora.launcher.data.Backup
import com.aurora.launcher.data.DrawerSort
import com.aurora.launcher.data.FolderStyle
import com.aurora.launcher.data.GestureAction
import com.aurora.launcher.data.IconShape
import com.aurora.launcher.data.IconTheme
import com.aurora.launcher.data.Keys
import com.aurora.launcher.data.LaunchAnimation
import com.aurora.launcher.data.LauncherSettings
import com.aurora.launcher.data.PageEffect
import com.aurora.launcher.data.ThemeMode
import com.aurora.launcher.ui.LauncherViewModel
import com.aurora.launcher.ui.components.IconArt
import com.aurora.launcher.ui.rememberDefaultLauncher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val accentPalette = listOf(
    0xFF5B5BD6, 0xFF3B82F6, 0xFF06B6D4, 0xFF10B981, 0xFF84CC16,
    0xFFF59E0B, 0xFFF97316, 0xFFEF4444, 0xFFEC4899, 0xFF8B5CF6,
).map { it.toInt() }

private fun Enum<*>.pretty() = name.lowercase().replace('_', ' ').replaceFirstChar { it.titlecase() }

@Composable
fun SettingsScreen(vm: LauncherViewModel, settings: LauncherSettings, startPage: String? = null, onClose: () -> Unit) {
    var page by rememberSaveable { mutableStateOf(startPage) }
    BackHandler { if (page != null) page = null else onClose() }
    val back = { if (page != null) page = null else onClose() }

    when (page) {
        null -> SettingsHome(vm, settings, onOpen = { page = it }, onClose = onClose)
        "appearance" -> AppearancePage(vm, settings, back)
        "icons" -> IconsPage(vm, settings, back)
        "home" -> HomePage(vm, settings, back)
        "quickaccess" -> QuickAccessPage(vm, settings, back)
        "drawer" -> DrawerPage(vm, settings, onHidden = { page = "hidden" }, onBack = back)
        "hidden" -> HiddenAppsPage(vm, settings) { page = "drawer" }
        "gestures" -> GesturesPage(vm, settings, back)
        "quick" -> QuickSettingsPage(vm, settings, back)
        "animations" -> AnimationsPage(vm, settings, back)
        "backup" -> BackupPage(vm, back)
        "about" -> AboutPage(back)
    }
}

@Composable
private fun SettingsHome(vm: LauncherViewModel, s: LauncherSettings, onOpen: (String) -> Unit, onClose: () -> Unit) {
    val default = rememberDefaultLauncher()
    val context = androidx.compose.ui.platform.LocalContext.current
    var confirmUninstall by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(false) }
    if (confirmUninstall) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmUninstall = false },
            title = { Text("Uninstall Aurora?") },
            text = { Text("Your layout and settings will be deleted. Back them up first if you want to keep them. Your phone will go back to its previous home app.") },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    confirmUninstall = false
                    try {
                        context.startActivity(
                            android.content.Intent(android.content.Intent.ACTION_DELETE, android.net.Uri.parse("package:${context.packageName}"))
                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                    }
                }) { Text("Uninstall") }
            },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmUninstall = false }) { Text("Cancel") } },
        )
    }
    SettingsPage("Customize", onClose) {
        if (!default.isDefault) {
            Group {
                NavRow("Make Aurora your home app", "Required for shortcuts and the Home button", Icons.Outlined.Home) { default.request() }
            }
        }
        Group {
            NavRow("Appearance", "Theme, colors, wallpaper, blur", Icons.Outlined.Palette) { onOpen("appearance") }
            Divider()
            NavRow("Icons", "Size, shape, labels, icon theme", Icons.Outlined.Apps) { onOpen("icons") }
            Divider()
            NavRow("Home screen", "Grid, dock, pages, folders", Icons.Outlined.GridView) { onOpen("home") }
            Divider()
            NavRow("Quick access", "Animated shortcuts, up to 10 apps", Icons.Outlined.Widgets) { onOpen("quickaccess") }
            Divider()
            NavRow("App drawer", "Grid, sorting, categories, hidden apps", Icons.Outlined.Category) { onOpen("drawer") }
            Divider()
            NavRow("Gestures", "Swipes, double tap, pinch", Icons.Outlined.Gesture) { onOpen("gestures") }
            Divider()
            NavRow("Quick settings", "Shortcuts shown in search", Icons.Outlined.Bolt) { onOpen("quick") }
            Divider()
            NavRow("Animations", "Launch animation and speed", Icons.Outlined.Speed) { onOpen("animations") }
        }
        Group {
            NavRow("Backup & restore", "Export or import your layout and settings", Icons.Outlined.Backup) { onOpen("backup") }
            Divider()
            NavRow("About & privacy", null, Icons.Outlined.Info) { onOpen("about") }
        }
        Group {
            ActionRow("Uninstall Aurora", "Remove this launcher from your phone") { confirmUninstall = true }
        }
    }
}

@Composable
private fun AppearancePage(vm: LauncherViewModel, s: LauncherSettings, onBack: () -> Unit) {
    val context = LocalContext.current
    val dynamicSupported = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S
    SettingsPage("Appearance", onBack) {
        Group("Theme") {
            ChoiceRow("Mode", ThemeMode.entries, s.themeMode, { it.pretty() }) { vm.set(Keys.THEME_MODE, it.name) }
            Divider()
            SwitchRow("Dynamic color", s.dynamicColor,
                if (dynamicSupported) "Match your wallpaper colors" else "Needs Android 12 or newer",
                enabled = dynamicSupported) { vm.set(Keys.DYNAMIC_COLOR, it) }
            Divider()
            val accentActive = !(s.dynamicColor && dynamicSupported)
            Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text("Accent color", style = MaterialTheme.typography.bodyLarge)
                Text(if (accentActive) "Used for buttons, highlights and tinted icons" else "Turn off dynamic color to choose",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    accentPalette.forEach { c ->
                        Box(
                            Modifier.size(26.dp).background(Color(c), CircleShape)
                                .then(if (s.accent == c) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                                .clickable(enabled = accentActive) { vm.set(Keys.ACCENT, c) }
                        )
                    }
                }
            }
        }
        Group("Wallpaper & glass") {
            ActionRow("Change wallpaper", "Opens the system wallpaper picker") {
                context.startActivity(
                    Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Set wallpaper").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            Divider()
            SliderRow("Wallpaper dimming", s.dimAmount, 0f..0.7f, label = { "${(it * 100).toInt()}%" }) { vm.set(Keys.DIM, it) }
            Divider()
            SliderRow("Glass opacity", s.glassAlpha, 0.2f..0.9f, label = { "${(it * 100).toInt()}%" }) { vm.set(Keys.GLASS, it) }
            Divider()
            SwitchRow("Blur wallpaper", s.blurWallpaper,
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) "Behind the drawer and search"
                else "Needs Android 12 or newer",
                enabled = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) { vm.set(Keys.BLUR, it) }
        }
        Group("Aurora look") {
            SwitchRow("Wallpaper-matched colors", s.adaptiveColors,
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) "Aurora colors follow your wallpaper"
                else "Needs Android 8.1 or newer; uses the default aurora colors") { vm.set(Keys.ADAPTIVE_COLORS, it) }
            Divider()
            SwitchRow("Aurora accent", s.auroraAccent, "Gradient rim, page dots, switches and sliders") { vm.set(Keys.AURORA_ACCENT, it) }
            Divider()
            SwitchRow("Soft glow", s.auroraGlow, "Color-shifting glow on search bar and icons") { vm.set(Keys.AURORA_GLOW, it) }
            Divider()
            SwitchRow("Moving ribbons", s.auroraRibbons, "Light ribbons behind the home screen; uses a little more battery") { vm.set(Keys.AURORA_RIBBONS, it) }
            Divider()
            SwitchRow("Gradient clock", s.auroraClock, "Gradient digits with a light streak under the date") { vm.set(Keys.AURORA_CLOCK, it) }
            Divider()
            SwitchRow("Icon shimmer", s.iconShimmer, "A light sweep when icons appear") { vm.set(Keys.ICON_SHIMMER, it) }
            Divider()
            SwitchRow("Startup animation", s.introAnimation, "Plays on first launch") { vm.set(Keys.INTRO_ANIM, it) }
            Divider()
            ActionRow("Replay startup animation") {
                vm.set(Keys.INTRO_ANIM, true)
                vm.set(Keys.INTRO_SEEN, false)
            }
        }
    }
}

@Composable
private fun QuickSettingsPage(vm: LauncherViewModel, s: LauncherSettings, onBack: () -> Unit) {
    val chosen = selectedQuickSettings(s.quickSettingIds)
    val others = quickSettings.filter { q -> chosen.none { it.id == q.id } }
    fun save(ids: List<String>) = vm.set(Keys.QUICK_IDS, ids.joinToString(","))
    fun move(i: Int, delta: Int) {
        val ids = chosen.map { it.id }.toMutableList()
        val j = i + delta
        if (j !in ids.indices) return
        val t = ids[i]; ids[i] = ids[j]; ids[j] = t
        save(ids)
    }
    SettingsPage("Quick settings", onBack) {
        Group("Shown in search, in this order") {
            chosen.forEachIndexed { i, q ->
                QuickRow(q, true, i > 0, i < chosen.lastIndex, { move(i, -1) }, { move(i, 1) }) {
                    save(chosen.map { it.id } - q.id)
                }
                if (i < chosen.lastIndex) Divider()
            }
            if (chosen.isEmpty()) Text(
                "Nothing selected",
                Modifier.padding(20.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Group("Available") {
            others.forEachIndexed { i, q ->
                QuickRow(q, false, false, false, {}, {}) { save(chosen.map { it.id } + q.id) }
                if (i < others.lastIndex) Divider()
            }
        }
        Hint("Flashlight switches on and off right from search. The others open the matching system settings page.")
    }
}

@Composable
private fun QuickRow(
    q: QuickSetting, selected: Boolean, canUp: Boolean, canDown: Boolean,
    onUp: () -> Unit, onDown: () -> Unit, onToggle: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(q.icon, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
        Text(q.label, Modifier.weight(1f).padding(start = 16.dp), style = MaterialTheme.typography.bodyLarge)
        if (selected) {
            IconButton(onClick = onUp, enabled = canUp) { Icon(Icons.Filled.KeyboardArrowUp, "Move up") }
            IconButton(onClick = onDown, enabled = canDown) { Icon(Icons.Filled.KeyboardArrowDown, "Move down") }
        }
        Switch(checked = selected, onCheckedChange = { onToggle() })
    }
}

@Composable
private fun IconsPage(vm: LauncherViewModel, s: LauncherSettings, onBack: () -> Unit) {
    SettingsPage("Icons", onBack) {
        Group("Icons") {
            SliderRow("Icon size", s.iconSizeDp.toFloat(), 40f..80f, 39, { "${it.toInt()} dp" }) { vm.set(Keys.ICON_SIZE, it.toInt()) }
            Divider()
            ChoiceRow("Shape", IconShape.entries, s.iconShape, { it.pretty() }) { vm.set(Keys.ICON_SHAPE, it.name) }
            Divider()
            ChoiceRow("Icon theme", IconTheme.entries, s.iconTheme, { it.pretty() }) { vm.set(Keys.ICON_THEME, it.name) }
        }
        Group("Labels") {
            SwitchRow("Show labels", s.showLabels) { vm.set(Keys.SHOW_LABELS, it) }
            Divider()
            SliderRow("Label size", s.labelSizeSp.toFloat(), 9f..16f, 6, { "${it.toInt()} sp" }) { vm.set(Keys.LABEL_SIZE, it.toInt()) }
            Divider()
            SwitchRow("Bold labels", s.labelBold) { vm.set(Keys.LABEL_BOLD, it) }
        }
        Hint("Adaptive icons from your apps are reshaped to match the shape you pick.")
    }
}

@Composable
private fun HomePage(vm: LauncherViewModel, s: LauncherSettings, onBack: () -> Unit) {
    var confirmReset by remember { mutableStateOf(false) }
    SettingsPage("Home screen", onBack) {
        Group("Grid") {
            SliderRow("Columns", s.gridColumns.toFloat(), 3f..6f, 2, { "${it.toInt()}" }) { vm.set(Keys.GRID_COLS, it.toInt()) }
            Divider()
            SliderRow("Rows", s.gridRows.toFloat(), 4f..8f, 3, { "${it.toInt()}" }) { vm.set(Keys.GRID_ROWS, it.toInt()) }
            Divider()
            SliderRow("Side padding", s.sidePaddingDp.toFloat(), 0f..32f, 7, { "${it.toInt()} dp" }) { vm.set(Keys.SIDE_PADDING, it.toInt()) }
            Divider()
            SliderRow("Row spacing", s.rowSpacingDp.toFloat(), 0f..32f, 7, { "${it.toInt()} dp" }) { vm.set(Keys.ROW_SPACING, it.toInt()) }
        }
        Group("Display") {
            SwitchRow("Status bar", s.showStatusBar, "Turn off for full screen") { vm.set(Keys.SHOW_STATUS_BAR, it) }
        }
        Group("Dock") {
            SwitchRow("Show dock", s.showDock) { vm.set(Keys.SHOW_DOCK, it) }
            Divider()
            SliderRow("Dock icons", s.dockCount.toFloat(), 3f..6f, 2, { "${it.toInt()}" }) { vm.set(Keys.DOCK_COUNT, it.toInt()) }
        }
        Group("Pages") {
            SwitchRow("Page indicator", s.pageIndicator) { vm.set(Keys.PAGE_INDICATOR, it) }
            Divider()
            ChoiceRow("Scroll effect", PageEffect.entries, s.pageEffect, { it.label }) { vm.set(Keys.PAGE_EFFECT, it.name) }
        }
        Group("Clock") {
            ChoiceRow("Position", HAlign.entries, s.clockAlign, { it.label }) { vm.set(Keys.CLOCK_ALIGN, it.name) }
            Divider()
            SliderRow("Size", s.clockScale, 0.6f..1.8f, label = { "${(it * 100).toInt()}%" }) { vm.set(Keys.CLOCK_SCALE, it) }
            Divider()
            SliderRow("Move down", s.clockOffsetY.toFloat(), 0f..160f, label = { "${it.toInt()} dp" }) { vm.set(Keys.CLOCK_OFFSET, it.toInt()) }
        }
        Group("Search bar") {
            ChoiceRow("Position", HAlign.entries, s.searchAlign, { it.label }) { vm.set(Keys.SEARCH_ALIGN, it.name) }
            Divider()
            SliderRow("Width", s.searchWidth, 0.4f..1f, label = { "${(it * 100).toInt()}%" }) { vm.set(Keys.SEARCH_WIDTH, it) }
            Divider()
            SliderRow("Size", s.searchScale, 0.8f..1.5f, label = { "${(it * 100).toInt()}%" }) { vm.set(Keys.SEARCH_SCALE, it) }
            Divider()
            SliderRow("Move down", s.searchOffsetY.toFloat(), 0f..160f, label = { "${it.toInt()} dp" }) { vm.set(Keys.SEARCH_OFFSET, it.toInt()) }
            Divider()
            ActionRow("Reset clock and search layout") {
                vm.set(Keys.CLOCK_ALIGN, HAlign.LEFT.name); vm.set(Keys.CLOCK_SCALE, 1f); vm.set(Keys.CLOCK_OFFSET, 0)
                vm.set(Keys.SEARCH_ALIGN, HAlign.CENTER.name); vm.set(Keys.SEARCH_WIDTH, 1f); vm.set(Keys.SEARCH_SCALE, 1f); vm.set(Keys.SEARCH_OFFSET, 0)
            }
        }
        Hint("Long-press an app icon on the home screen and choose Icon size to resize it.")
        Group("Widgets & folders") {
            SwitchRow("Clock and date", s.showClock) { vm.set(Keys.SHOW_CLOCK, it) }
            Divider()
            SwitchRow("Search bar", s.showSearchBar) { vm.set(Keys.SHOW_SEARCH, it) }
            Divider()
            ChoiceRow("Folder style", FolderStyle.entries, s.folderStyle, { it.pretty() }) { vm.set(Keys.FOLDER_STYLE, it.name) }
        }
        Group {
            ActionRow("Reset home layout", "Clears every icon and folder from the home screen") { confirmReset = true }
        }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset home layout?") },
            text = { Text("All icons and folders on your home screen will be removed. Your apps are not uninstalled.") },
            confirmButton = { TextButton(onClick = { vm.resetLayout(); confirmReset = false }) { Text("Reset") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun DrawerPage(vm: LauncherViewModel, s: LauncherSettings, onHidden: () -> Unit, onBack: () -> Unit) {
    SettingsPage("App drawer", onBack) {
        Group("Layout") {
            SliderRow("Columns", s.drawerColumns.toFloat(), 3f..6f, 2, { "${it.toInt()}" }) { vm.set(Keys.DRAWER_COLS, it.toInt()) }
            Divider()
            ChoiceRow("Sort by", DrawerSort.entries, s.drawerSort, {
                when (it) {
                    DrawerSort.AZ -> "A to Z"
                    DrawerSort.ZA -> "Z to A"
                    DrawerSort.NEWEST -> "Recently installed"
                    DrawerSort.MOST_USED -> "Most used"
                }
            }) { vm.set(Keys.DRAWER_SORT, it.name) }
            Divider()
            SwitchRow("Group by category", s.drawerCategories, "Games, media, social and more") { vm.set(Keys.DRAWER_CATEGORIES, it) }
            Divider()
            SwitchRow("Suggestions", s.drawerSuggestions, "Frequently used and recently installed apps") { vm.set(Keys.DRAWER_SUGGESTIONS, it) }
        }
        Group("Search") {
            SwitchRow("Open keyboard automatically", s.searchAutoKeyboard) { vm.set(Keys.SEARCH_KEYBOARD, it) }
            Divider()
            SwitchRow("Enter launches top result", s.searchLaunchSingle) { vm.set(Keys.SEARCH_LAUNCH_SINGLE, it) }
        }
        Group {
            NavRow("Hidden apps", "${s.hiddenApps.size} hidden", Icons.Outlined.VisibilityOff, onHidden)
        }
    }
}

@Composable
private fun HiddenAppsPage(vm: LauncherViewModel, s: LauncherSettings, onBack: () -> Unit) {
    val apps by vm.allApps.collectAsStateWithLifecycle()
    BackHandler(onBack = onBack)
    SettingsPage("Hidden apps", onBack) {
        Hint("Hidden apps disappear from the drawer and search. They keep working and stay on the home screen if already placed.")
        Group {
            apps.forEach { app ->
                val hidden = app.key in s.hiddenApps
                Row(
                    Modifier.fillMaxWidth().clickable { vm.setHidden(app, !hidden) }.padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    IconArt(app, s, 40.dp)
                    Text(app.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    androidx.compose.material3.Switch(checked = hidden, onCheckedChange = null)
                }
            }
        }
    }
}

@Composable
private fun QuickAccessPage(vm: LauncherViewModel, s: LauncherSettings, onBack: () -> Unit) {
    val apps by vm.allApps.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val sorted = remember(apps) { apps.sortedBy { it.label.lowercase() } }
    val picked = s.quickApps
    fun save(list: List<String>) = vm.set(Keys.QUICK_APPS, list.joinToString("\n"))
    SettingsPage("Quick access", onBack) {
        Group {
            SwitchRow("Show quick access", s.quickEnabled, "One tap opens your favorite apps, so they stay off the home screen") {
                vm.set(Keys.QUICK_ENABLED, it)
            }
        }
        Group("Style") {
            ChoiceRow("Style", QuickStyle.entries, s.quickStyle, { it.label }) { vm.set(Keys.QUICK_STYLE, it.name) }
            Divider()
            ChoiceRow("Position", HAlign.entries, s.quickAlign, { it.label }) { vm.set(Keys.QUICK_ALIGN, it.name) }
            Divider()
            SwitchRow("Haptic feedback", s.quickHaptics) { vm.set(Keys.QUICK_HAPTICS, it) }
        }
        Hint("Edge drawer opens from the left or right edge; Center uses the right edge.")
        Group("Apps (${picked.size} of $QuickMaxApps)") {
            sorted.forEach { app ->
                val on = app.key in picked
                Row(
                    Modifier.fillMaxWidth().clickable {
                        when {
                            on -> save(picked - app.key)
                            picked.size >= QuickMaxApps ->
                                Toast.makeText(context, "You can pick up to $QuickMaxApps apps", Toast.LENGTH_SHORT).show()
                            else -> save(picked + app.key)
                        }
                    }.padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    IconArt(app, s, 40.dp)
                    Text(app.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    Switch(checked = on, onCheckedChange = null)
                }
            }
        }
        Hint("Apps appear in the order you pick them. Pick none to use your 5 most used apps.")
    }
}

@Composable
private fun GesturesPage(vm: LauncherViewModel, s: LauncherSettings, onBack: () -> Unit) {
    val all = GestureAction.entries
    SettingsPage("Gestures", onBack) {
        Group {
            ChoiceRow("Swipe up", all, s.swipeUp, { it.label }) { vm.set(Keys.SWIPE_UP, it.name) }
            Divider()
            ChoiceRow("Swipe down", all, s.swipeDown, { it.label }) { vm.set(Keys.SWIPE_DOWN, it.name) }
            Divider()
            ChoiceRow("Double tap on empty space", all, s.doubleTap, { it.label }) { vm.set(Keys.DOUBLE_TAP, it.name) }
            Divider()
            ChoiceRow("Pinch in", all, s.pinch, { it.label }) { vm.set(Keys.PINCH, it.name) }
        }
        Hint("\"Recent apps\" opens Aurora's own switcher with small window and close app. Android's built-in Recents screen cannot be changed by a launcher.")
    }
}

@Composable
private fun AnimationsPage(vm: LauncherViewModel, s: LauncherSettings, onBack: () -> Unit) {
    SettingsPage("Animations", onBack) {
        Group {
            ChoiceRow("App opening", LaunchAnimation.entries, s.launchAnimation, {
                when (it) { LaunchAnimation.ZOOM -> "Zoom from icon"; LaunchAnimation.FADE -> "Fade"; LaunchAnimation.NONE -> "None" }
            }) { vm.set(Keys.LAUNCH_ANIM, it.name) }
            Divider()
            SliderRow("Launcher animation speed", s.animationSpeed, 0.5f..1.5f, 9, { "%.1fx".format(it) }) { vm.set(Keys.ANIM_SPEED, it) }
        }
        Hint("Speed applies to the drawer and overlays. App-to-app transitions follow the system animation scale.")
    }
}

@Composable
private fun BackupPage(vm: LauncherViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            val ok = try {
                val json = Backup.toJson(vm.settingsRepository.snapshot(), vm.allHomeItems())
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) } != null
                }
            } catch (e: Exception) { false }
            Toast.makeText(context, if (ok) "Backup saved" else "Could not save backup", Toast.LENGTH_SHORT).show()
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val parsed = try {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { Backup.parse(it.readBytes().decodeToString()) }
                }
            } catch (e: Exception) { null }
            if (parsed == null) {
                Toast.makeText(context, "Not a valid Aurora backup", Toast.LENGTH_SHORT).show()
            } else {
                vm.settingsRepository.restore(parsed.settings)
                vm.replaceHomeItems(parsed.items)
                Toast.makeText(context, "Backup restored", Toast.LENGTH_SHORT).show()
            }
        }
    }

    SettingsPage("Backup & restore", onBack) {
        Group {
            ActionRow("Export backup", "Saves settings and home layout to a file you choose") { exportLauncher.launch("aurora-backup.json") }
            Divider()
            ActionRow("Restore from backup", "Replaces current settings and home layout") { importLauncher.launch(arrayOf("*/*")) }
        }
        Hint("Backups contain only launcher settings, icon placement and hidden-app names. They never leave your device unless you move the file.")
    }
}

@Composable
private fun AboutPage(onBack: () -> Unit) {
    val default = rememberDefaultLauncher()
    SettingsPage("About & privacy", onBack) {
        Group {
            ActionRow(
                if (default.isDefault) "Aurora is your home app" else "Make Aurora your home app",
                if (default.isDefault) "Pressing Home opens Aurora" else "Tap to choose",
            ) { if (!default.isDefault) default.request() }
        }
        Group("Privacy") {
            Hint("Aurora has no internet access, no analytics and no accounts. Everything is stored on this device.")
        }
        Group("Permissions explained") {
            Hint("See all apps: so your drawer can list every installed app.")
            Hint("Uninstall apps: to open the system uninstall dialog from the long-press menu.")
            Hint("Expand notification shade: so the swipe-down gesture can open it.")
        }
        Text("Version 1.0.0", Modifier.padding(28.dp), style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
